from public import queryToJson as toJson
from bookManage import models
from django.conf import settings
from django.db import connection
from ffmpy import FFmpeg
import json
from public import file
from public import cosFile
from collections import Counter
from collections import OrderedDict
import random
import jieba
import operator
import re
import os
import time
import uuid


def getTypes():
    data = models.TBookTypes.objects.values()
    types = toJson.getJson(data)
    res = []
    res.append({'book_type_id': '', 'type_name': '全部分类', 'parent_id': ''})
    for item in types:
        if int(item['book_type_id']) < 100:
            res.append(item)
    print(res)
    if len(res) == 0:
        return False
    else:
        return res


def getBookCover(type_id, universityId):
    cursor = connection.cursor()
    sql = 'SELECT sail_id,book_img,BOOK_TYPE_ID_CHILD,TYPE_NAME_CHILD,BOOK_TYPE_ID,univercity_id FROM jsg.v_sail_book group by BOOK_TYPE_ID_CHILD ' +\
        "having BOOK_TYPE_ID_CHILD in(select BOOK_TYPE_ID from t_book_types where BOOK_TYPE_ID like '" + \
        type_id + "%') and univercity_id =\'" + universityId + "'"
    cursor.execute(sql)
    res = []
    for item in cursor.fetchall():
        book = {}
        book['sail_id'] = item[0]
        book['book_img'] = item[1]
        book['book_type_id_child'] = item[2]
        book['book_name'] = item[3]
        book['book_type_id'] = item[4]
        res.append(book)
    return res


def getBooksInfo(sortIndex, ip):
    cursor = connection.cursor()
    sql = "SELECT DISTINCT SAIL_ID,BOOK_NAME,BOOK_IMG,BOOK_AUTHOR,BOOK_PUBLISHER,MARKS,SAILEDNUM,STOCK_TOTAL,SAIL_PRICE" +\
        " FROM jsg.v_sail_book where SAIL_PRICE!='' and STOCK_TOTAL!='' and univercity_id=\'" + \
        sortIndex['universityId'] + "\' "
    if sortIndex['type_id']:   # type ID
        sql = sql + 'and book_type_id=\'' + \
            sortIndex['type_id'] + '\' '
    if sortIndex['book_type_id_child']:
        sql = sql + 'and book_type_id_child=\'' + \
            sortIndex['book_type_id_child'] + '\' '
    if sortIndex['price_begin']:
        sql = sql + 'and SAIL_PRICE>=' + sortIndex['price_begin']
    if sortIndex['price_end'] != '0' and sortIndex['price_end'] != '':
        sql = sql + ' and SAIL_PRICE<=' + sortIndex['price_end']
    if sortIndex['key']:
        words = jieba.lcut(sortIndex['key'])
        sql = sql + " and (book_name like '%" + \
            sortIndex['key'] + "%' or book_name like '%" + \
            words[0] + "%' or book_author like '%" + \
            sortIndex['key'] + "%' or book_author like '%" + \
            words[0] + "%' or book_isbn like '%" +\
            sortIndex['key'] + "%')"
        models.TSearchRec.objects.create(
            id=uuid.uuid4(), key=sortIndex['key'], ip=ip)
    if sortIndex['sail'] == '-1':  # sort desc by sail num
        sql = sql + ' ORDER BY SAILEDNUM DESC,RAND()'
    elif sortIndex['price'] == '1':  # sort asc by sail price
        sql = sql + ' ORDER BY SAIL_PRICE ASC,RAND()'
    elif sortIndex['price'] == '-1':  # sort desc by sail price
        sql = sql + ' ORDER BY SAIL_PRICE DESC,RAND()'
    else:
        sql = sql + ' ORDER BY RAND()'
    sql = sql + ' limit ' + sortIndex['page'] + ',10'
    cursor.execute(sql)
    res = []
    for item in cursor.fetchall():
        book = {}
        book['sail_id'] = item[0]
        book['book_name'] = item[1][0:20]
        book['book_img'] = item[2]
        book['book_author'] = item[3][0:15]
        book['book_publisher'] = item[4][0:15]
        book['marks'] = item[5]
        book['sailed'] = item[6]
        book['stock_total'] = str(item[7])
        book['book_price'] = str(item[8])
        res.append(book)
    return res


def getBooksInfo_Detail(sail_id, univercity_id, book_isbn):
    cursor = connection.cursor()
    if sail_id:
        sql = "SELECT DISTINCT * FROM jsg.v_sail_book where sail_id=" + \
            sail_id
    elif book_isbn:
        sql = "SELECT DISTINCT * FROM jsg.v_sail_book where univercity_id='" + \
            univercity_id + "' and book_isbn=" + book_isbn
    else:
        sql = ''
    cursor.execute(sql)
    book = {}
    item = cursor.fetchone()
    if item:
        book['sail_id'] = item[0]
        book['univercity_id'] = item[1]
        book['book_isbn'] = item[2]
        book['book_name'] = item[4][0:20]
        book['book_author'] = item[8]
        book['book_publisher'] = item[9][0:15]
        book['book_publish_year'] = item[10]
        book['book_introduce'] = item[11].split('\n')[1]
        book['book_content'] = item[12].split('\n')
        book['book_imgs'] = item[14].split(' ')
        book['marks'] = item[15]
        book['type_name'] = item[16]
        book['type_name_child'] = item[17]
        book['sailed'] = item[18]
        book['stock_total'] = str(item[19])
        book['sail_price'] = str(item[20])
        return book
    else:
        return False


def getHot():
    data = list(models.TSearchRec.objects.all().values('key'))
    hot = []
    res = []
    for item in data:
        hot.append(item['key'])
    set_a = list(set(hot))  # 去重得到一个集合
    count_set_a = {}  # 存放元素和出现次数的字典，key为元素,value为出现次数
    for item in set_a:
        count_set_a[item] = hot.count(item)
    sorted_hot = sorted(count_set_a.items(), key=operator.itemgetter(1))
    result_a = []  # 存放最后的结果
    for item in sorted_hot[::-1]:  # 按value值从大到小排序
        result_a.append(item[0])
    return json.dumps(result_a[0:5])


def getBooksInfo_Stock(sail_id):
    stockData = list(models.TSailBookStock.objects.filter(
        sail_id=sail_id).values())
    res = []
    for item in stockData:
        stock = {}
        stock['stock_id'] = item['stock_id']
        stock['newLevel'] = item['book_new']
        stock['new_stock'] = item['book_stock']
        stock['new_price'] = str(item['book_price'])
        res.append(stock)
    if len(res) == 0:
        return False
    else:
        return res

'''
function：音频格式转换mp3 == >pcm
parameters@filePath: 文件路径
return@None
data:2018/09/06
author:Ricky
'''


def mp3ToPcm(filePath):
    ff = FFmpeg(inputs={filePath + '.mp3': None}, outputs={
        filePath + '.pcm': '-y -i ' + filePath + '.mp3 -acodec pcm_s16le -f s16le -ac 1 -ar 16000'})
    ff.run()


def vToW(vFile):
    filename = str(time.time())
    try:
        if file.setFile(filename + '.mp3', vFile) == 0:
            mp3ToPcm(filename)  # MP3转pcm
            # 识别本地文件
            res = settings.VCLIENT.asr(file.getFile(filename + '.pcm'),
                                       'pcm', 16000, {'dev_pid': '1536'})
            if res['err_no'] == 0:
                # 录音文字
                return ''.join(e for e in res['result'][0] if e.isalnum())
            else:
                return 'error'
        else:
            return 'error'
    except:
        return 'error'
    finally:
        # 删除临时文件
        if (os.path.exists(filename + 'mp3')):
            os.remove(filename + '.mp3')
        if (os.path.exists(filename + 'pcm')):
            os.remove(filename + '.pcm')
