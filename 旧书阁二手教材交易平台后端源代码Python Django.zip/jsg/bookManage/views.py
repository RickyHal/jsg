from django.shortcuts import render
from django.conf import settings
from django.http import HttpResponse
from django.http.response import JsonResponse
from bookManage import api as book

import json


def getTypes(request):
    if request.method == 'POST':
        data = book.getTypes()
        if data:
            res = {'status': 0, 'data': data}
        else:
            res = {'status': 1, 'data': ''}
        return HttpResponse(json.dumps(res), content_type="application/json")
    else:
        res = {'status': 1, 'data': ''}
        return HttpResponse(json.dumps(res), content_type="application/json")


def getBookCover(request):
    if request.method == 'POST':
        universityId = request.POST['universityId']
        type_id = request.POST['typeId']
        print(type_id)
        data = book.getBookCover(type_id, universityId)
        if len(data) == 0:
            res = {'status': 0, 'data': []}
        else:
            res = {'status': 0, 'data': data}
        return HttpResponse(json.dumps(res), content_type="application/json")
    else:
        res = {'status': 1, 'data': ''}
        return HttpResponse(json.dumps(res), content_type="application/json")


def Voice(request):
    if request.method == 'POST':
        file = request.FILES['voice']  # file
        res = book.vToW(file)
        return HttpResponse(res, content_type="application/json")
    else:
        return HttpResponse('please use post method')


def getHot(request):
    if request.method == 'POST':
        res = book.getHot()
        return HttpResponse(res, content_type="application/json")
    else:
        return HttpResponse('please use post method')


def getBooksInfo(request):
    if request.method == 'POST':
        sortIndex = {}
        try:
            sortIndex['key'] = request.POST['key']
        except:
            sortIndex['key'] = ''
        sortIndex['page'] = request.POST['page']
        sortIndex['sail'] = request.POST['sail']
        sortIndex['price'] = request.POST['price']
        sortIndex['price_begin'] = request.POST['price_begin']
        sortIndex['price_end'] = request.POST['price_end']
        sortIndex['type_id'] = request.POST['typeId']
        sortIndex['universityId'] = request.POST['universityId']
        sortIndex['book_type_id_child'] = request.POST['book_type_id_child']
        ip = request.META['REMOTE_ADDR']
        print(sortIndex)
        data = book.getBooksInfo(sortIndex, ip)
        if len(data) == 0:
            res = {'status': 0, 'data': []}
        else:
            res = {'status': 0, 'data': data}
        return HttpResponse(json.dumps(res), content_type="application/json")
    else:
        res = {'status': 1, 'data': ''}
        return HttpResponse(json.dumps(res), content_type="application/json")


def getBooksInfo_Detail(request):
    if request.method == 'POST':
        sail_id = request.POST['sail_id']
        try:
            book_isbn = request.POST['book_isbn']
        except:
            book_isbn = ''
        univercity_id = request.POST['univercity_id']
        data = book.getBooksInfo_Detail(sail_id, univercity_id, book_isbn)
        if data == False:
            res = {'status': 0, 'data': ''}
        else:
            res = {'status': 0, 'data': data}
        return HttpResponse(json.dumps(res), content_type="application/json")
    else:
        res = {'status': 1, 'data': ''}
        return HttpResponse(json.dumps(res), content_type="application/json")


def getBooksInfo_Stock(request):
    if request.method == 'POST':
        sail_id = request.POST['sail_id']
        data = book.getBooksInfo_Stock(sail_id)
        if data == False:
            res = {'status': 0, 'data': []}
        else:
            res = {'status': 0, 'data': data}
        return HttpResponse(json.dumps(res), content_type="application/json")
    else:
        res = {'status': 1, 'data': ''}
        return HttpResponse(json.dumps(res), content_type="application/json")
