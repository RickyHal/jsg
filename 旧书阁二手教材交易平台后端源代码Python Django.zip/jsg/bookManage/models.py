from django.db import models
from bookManage import models as book
from userStatusManage import models as user
# Create your models here.


class TBook(models.Model):
    # Field name made lowercase.
    book_id = models.CharField(
        db_column='BOOK_ID', primary_key=True, max_length=20)
    # Field name made lowercase.
    book_isbn = models.CharField(db_column='BOOK_ISBN', max_length=13)
    # Field name made lowercase.
    book_name = models.CharField(db_column='BOOK_NAME', max_length=50)
    # Field name made lowercase.
    book_img = models.CharField(db_column='BOOK_IMG', max_length=200)
    # Field name made lowercase.
    book_type = models.ForeignKey(
        'TBookTypes', models.DO_NOTHING, db_column='BOOK_TYPE_ID', blank=True, null=True)
    # Field name made lowercase.
    book_type_id_child = models.CharField(
        db_column='BOOK_TYPE_ID_CHILD', max_length=4)
    # Field name made lowercase.
    book_author = models.CharField(db_column='BOOK_AUTHOR', max_length=50)
    # Field name made lowercase.
    book_publisher = models.CharField(
        db_column='BOOK_PUBLISHER', max_length=50)
    # Field name made lowercase.
    book_publish_year = models.CharField(
        db_column='BOOK_PUBLISH_YEAR', max_length=20)
    # Field name made lowercase.
    book_introduce = models.CharField(
        db_column='BOOK_INTRODUCE', max_length=10000, blank=True, null=True)
    # Field name made lowercase.
    book_content = models.CharField(
        db_column='BOOK_CONTENT', max_length=10000, blank=True, null=True)
    # Field name made lowercase.
    book_price = models.DecimalField(
        db_column='BOOK_PRICE', max_digits=4, decimal_places=2)

    class Meta:
        managed = False
        db_table = 't_book'


class TSailBook(models.Model):
    # Field name made lowercase.
    sail_id = models.CharField(
        db_column='SAIL_ID', primary_key=True, max_length=20)
    # Field name made lowercase.
    book = models.ForeignKey(
        TBook, models.DO_NOTHING, db_column='BOOK_ID')
    # Field name made lowercase.
    book_imgs = models.CharField(db_column='BOOK_IMGS', max_length=1000)
    # Field name made lowercase.
    book_marks = models.CharField(
        db_column='BOOK_MARKS', max_length=10, blank=True, null=True)
    # Field name made lowercase.
    univercity = models.ForeignKey(
        'public.TUnivercity', models.DO_NOTHING, db_column='UNIVERCITY_ID')

    class Meta:
        managed = False
        db_table = 't_sail_book'


class TSearchRec(models.Model):
    # Field name made lowercase.
    id = models.CharField(
        db_column='ID', primary_key=True, max_length=36)
    # Field name made lowercase.
    time = models.DateTimeField(
        db_column='TIME', auto_now_add=True)
    # Field name made lowercase.
    key = models.CharField(db_column='KEY', max_length=100)
    # Field name made lowercase.
    ip = models.CharField(db_column='IP', max_length=15)

    class Meta:
        managed = False
        db_table = 't_search_rec'


class TSailBookStock(models.Model):
    # Field name made lowercase.
    stock_id = models.CharField(
        db_column='STOCK_ID', primary_key=True, max_length=20)
    # Field name made lowercase.
    sail = models.ForeignKey(TSailBook, models.DO_NOTHING,
                             db_column='SAIL_ID', blank=True, null=True)
    # Field name made lowercase.
    book_new = models.IntegerField(db_column='BOOK_NEW')
    # Field name made lowercase.
    book_stock = models.IntegerField(db_column='BOOK_STOCK')
    # Field name made lowercase.
    book_price = models.DecimalField(
        db_column='BOOK_PRICE', max_digits=4, decimal_places=2)

    class Meta:
        managed = False
        db_table = 't_sail_book_stock'


class TBookTypes(models.Model):
    # Field name made lowercase.
    book_type_id = models.CharField(
        db_column='BOOK_TYPE_ID', primary_key=True, max_length=4)
    # Field name made lowercase.
    type_name = models.CharField(db_column='TYPE_NAME', max_length=20)
    # Field name made lowercase.
    parent_id = models.CharField(
        db_column='PARENT_ID', max_length=4, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 't_book_types'
