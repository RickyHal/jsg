from django.contrib import admin
from django.urls import path
from userStatusManage import views as user
from errorHandle import views as errorHandle
from bookManage import views as book
from pageHandle import views as pageHandle
from shareBookManage import views as shareBook
from my import views as my
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', pageHandle.index, name='index'),
    path('user/signUp', user.signUp),
    path('user/getUnivercitys', user.getUnivercitys),
    path('user/getEmailCode', user.getEmailCode),
    path('user/logIn', user.logIn),
    path('user/logOut', user.logOut),
    path('user/modifyPasswd', user.modifyPasswd),
    path('user/modifyInfo', user.modifyInfo),
    path('user/getUserInfo', user.getUserInfo),
    path('user/book/getTypes', book.getTypes),
    path('user/book/getBookCover', book.getBookCover),
    path('user/book/getBooksInfo', book.getBooksInfo),
    path('user/book/getBooksInfo_Detail', book.getBooksInfo_Detail),
    path('user/book/getBooksInfo_Stock', book.getBooksInfo_Stock),
    path('user/book/voice', book.Voice),
    path('user/book/hot', book.getHot),
    path('user/appoint', my.appoint),
    path('user/getAppointments', my.getAppointments),
    path('user/cancelAppointment', my.cancelAppointment),
    path('user/upShareImgs', shareBook.upShareImgs),
    path('user/amShareBook', shareBook.amShareBook),
    path('user/getMyShareInfo', shareBook.getMyShareInfo),
    path('user/getBorrowRec', shareBook.getBorrowRec),
    path('user/shareManage', shareBook.shareManage),
    path('user/getShareList', shareBook.getShareList),
    path('user/getShareBookDetail', shareBook.getShareBookDetail),
    path('user/borrowShareBook', shareBook.borrow)
]
# 处理错误
handler403 = errorHandle.page_403
handler404 = errorHandle.page_404
handler500 = errorHandle.page_500
