"""
file_name:views.py
app:errorHandle
funtion:handle error
include:
 1.function:page_403@handle 403 error
 2.function:page_404@handle 404 error
 3.function:page_500@handle 500 error
data:2018/09/06
author:Ricky
"""

from django.http import HttpResponse
from django.shortcuts import render

'''
function：handle 403 error
parameters@request
render@templates/403.html@ip:the visitor's ip
date:2018/09/06
'''


def page_403(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]  # real ip
    else:
        ip = request.META.get('REMOTE_ADDR')  # proxy ip
    print('403   ' + ip)
    ip = {'ip': ip}
    return render(request, 'errorPage\\403.html', ip)


'''
function：handle 404 error
parameters@request
render@templates / 404.html@ip: the visitor's ip
date: 2018 / 09 / 06
'''


def page_404(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]  # real ip
    else:
        ip = request.META.get('REMOTE_ADDR')  # proxy ip
    print('404  ' + ip)
    ip = {'ip': ip}
    return render(request, 'errorPage\\403.html', ip)


'''
function：handle 500 error
parameters@request
render@templates / 500.html@ip: the visitor's ip
date: 2018 / 09 / 06
'''


def page_500(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]  # real ip
    else:
        ip = request.META.get('REMOTE_ADDR')  # proxy ip
    print('500  ' + ip)
    ip = {'ip': ip}
    return render(request, 'errorPage\\403.html', ip)
