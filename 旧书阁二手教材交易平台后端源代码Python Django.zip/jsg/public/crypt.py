from django.conf import settings


def encrypt(text):
    return (settings.CRYPT_KEY + text + settings.CRYPT_IV).encode('utf-8')


def decrypt(text):
    return (text.decode('utf-8')).replace(settings.CRYPT_IV, '').replace(settings.CRYPT_KEY, '')
