import datetime


def dateToStr(split):
    return str(datetime.datetime.now().year) + split + \
        str(datetime.datetime.now().month) + \
        split + str(datetime.datetime.now().day)
