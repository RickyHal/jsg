from django.conf import settings
from public import queryToJson as toJson
from public import models
import pymysql
import json
import random
import string
import datetime


def getSession(key):
    data = models.TSession.objects.get(session_key=key)
    return json.loads((data.data).replace("'", "\""))


def setSession(value):
    try:
        session_key = getSessionKey()
        models.TSession.objects.create(
            session_key=session_key, data=str(value))
        return session_key
    except:
        return False


def deleteSession(session_key):
    try:
        models.TSession.objects.filter(session_key=session_key).delete()
        return True
    except:
        return False


def getSessionKey():
    return ''.join(random.sample(string.ascii_letters + string.digits, 32))
