from django.conf import settings
from public import queryToJson as toJson
from public import models
import json


def getUnivercitys():
    data = models.TUnivercity.objects.values()
    res = toJson.getJson(data)
    return res
