import re


def checkEmail(email):
    pattern = re.compile(
        r"^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$")
    if pattern.match(email):
        return True
    else:
        return False
