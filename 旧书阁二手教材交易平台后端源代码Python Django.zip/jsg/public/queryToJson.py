'''
file_name:queryToJson.py
app:all
funtion:transport the database query set to json data
include:
 1.function:getJson: transport the database query set to json data
data:2018/10/01
author:Ricky
'''

import json

'''
function：transport the database query set to json data
parameters@data: the query set  data
return@json.dumps(res): the json data of query set
json.dumps(res)
author:Ricky
'''


def getJson(data):
    res = []
    for item in data:
        if item not in res:
            res.append(item)
    return res
