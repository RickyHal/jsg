import random
from django.conf import settings
import smtplib
from email.mime.text import MIMEText
from email.header import Header


def sendCheckCode(toEmail):
    subject = '旧书阁APP邮箱验证码'
    code = getCode()
    msg = MIMEText('您的验证码为：' + code + '，有效时间30分钟。', 'plain', 'utf-8')
    msg['Subject'] = Header(subject, 'utf-8')
    msg['from'] = settings.SENDER
    msg['to'] = toEmail
    try:
        smtp = smtplib.SMTP()
        smtp.connect(settings.SMTPSERVER)
        smtp.login(settings.USER, settings.PASSWD)
        smtp.sendmail(settings.SENDER, toEmail, msg.as_string())
        smtp.quit()
        return code
    except:
        return 1


def getCode():
    code = ""
    for i in range(6):
        ch = chr(random.randrange(ord('0'), ord('9') + 1))
        code += ch
    return code
