from django.db import models


class TSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=32)
    time = models.DateTimeField(auto_now_add=True)
    data = models.CharField(max_length=1000)

    class Meta:
        managed = False
        db_table = 't_session'


class TUnivercity(models.Model):
    # Field name made lowercase.
    univercity_id = models.CharField(
        db_column='UNIVERCITY_ID', primary_key=True, max_length=10)
    # Field name made lowercase.
    univercity_name = models.CharField(
        db_column='UNIVERCITY_NAME', max_length=50)

    class Meta:
        managed = False
        db_table = 't_univercity'
