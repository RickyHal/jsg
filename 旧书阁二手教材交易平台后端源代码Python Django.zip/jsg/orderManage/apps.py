from django.apps import AppConfig


class OrdermanageConfig(AppConfig):
    name = 'orderManage'
