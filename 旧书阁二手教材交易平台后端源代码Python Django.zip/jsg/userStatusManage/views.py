from django.shortcuts import render
from django.conf import settings
from django.http import HttpResponse
from public import sendEmail
from public import session
from public import crypt
from userStatusManage import api as user
import json


def getUnivercitys(request):
    if request.method == 'POST':
        res = user.getUnivercitys()
        return HttpResponse(json.dumps(res, ensure_ascii=False), content_type="application/json")
    else:
        res = {'status': 1}
        return HttpResponse(json.dumps(res), content_type="application/json")


def signUp(request):
    if request.method == 'POST':
        userInfo = {}
        userInfo['univercity_id'] = request.POST['univercityId']
        userInfo[
            'user_logo'] = 'https://uuclock-1254170634.cos.ap-chengdu.myqcloud.com/JSG/user/logo/logo.png'
        userInfo['user_name'] = request.POST['username']
        userInfo['name'] = request.POST['name']
        userInfo['user_passwd'] = request.POST['passwd']
        userInfo['user_tel'] = request.POST['tel']
        userInfo['user_qq'] = request.POST['qq']
        userInfo['user_email'] = request.POST['email']
        code = request.POST['code']
        session_key = request.POST['session_key']
        sessionData = session.getSession(session_key)
        if sessionData['hasSignUp'] == 1 and sessionData['code'] == code and user.checkUser(userInfo['user_name'], 'username') == 1:
            res = {'status': 0, 'data': {'result': 0}}
            if user.signUp(userInfo):
                res['data']['result'] = 0
            else:
                res['data']['result'] = 1
        elif (sessionData['hasSignUp'] == 1 and sessionData['code'] != code):
            res = {'status': 0, 'data': {'result': 2}}
        else:
            res = {'status': 0, 'data': {'result': 3}}  # has sign up
        return HttpResponse(json.dumps(res), content_type="application/json")
    else:
        res = {'status': 1, 'data': ''}
        return HttpResponse(json.dumps(res), content_type="application/json")


def logIn(request):
    if request.method == 'POST':
        username = request.POST['username']
        passwd = request.POST['passwd']
        # user isn's exist
        if user.checkUser(username, 'username') == 0 or user.checkUser(username, 'email') == 0:
            logRes = user.logIn(username, passwd)
            if logRes != False:  # password error
                data = {'user_id': logRes}
                session_key = session.setSession(data)
                res = {'status': 0, 'data': {
                    'result': 0, 'session_key': session_key}}
            else:
                res = {'status': 0, 'data': {'result': 1}}
        else:
            res = {'status': 1, 'data': {'result': 1}}
        return HttpResponse(json.dumps(res), content_type="application/json")
    else:
        res = {'status': 1, 'data': ''}
        return HttpResponse(json.dumps(res), content_type="application/json")


def logOut(request):
    if request.method == 'POST':
        session_key = request.POST['session_key']
        sessionData = session.getSession(session_key)
        if session.deleteSession(session_key):
            res = {'status': 0, 'data': {'result': 0}}
        else:
            res = {'status': 0, 'data': {'result': 1}}
        return HttpResponse(json.dumps(res), content_type="application/json")
    else:
        res = {'status': 1, 'data': ''}
        return HttpResponse(json.dumps(res), content_type="application/json")


def modifyPasswd(request):
    if request.method == 'POST':
        email = request.POST['email']
        code = request.POST['code']
        newPasswd = request.POST['newPasswd']
        session_key = request.POST['session_key']
        sessionData = session.getSession(session_key)
        res = {'status': 1, 'data': {
            'result': 1, 'codeCheck': 1, 'hasSignUp': 1}}
        if sessionData and sessionData['hasSignUp'] == 0:
            if sessionData['code'] == code:  # check the email check code
                # modify the user's password
                if user.modifyPasswd(email, newPasswd):
                    # delete the session data
                    if session.deleteSession(session_key):
                        res['status'] = 0
                        res['data']['result'] = 0
                        res['data']['codeCheck'] = 0
                        res['data']['hasSignUp'] = 0
                    else:  # delete session failed
                        res['status'] = 0
                        res['data']['result'] = 1
                        res['data']['codeCheck'] = 0
                        res['data']['hasSignUp'] = 0
                else:  # modify failed
                    res['status'] = 0
                    res['data']['result'] = 1
                    res['data']['codeCheck'] = 0
                    res['data']['hasSignUp'] = 0
            else:  # check code error
                res['status'] = 0
                res['data']['result'] = 1
                res['data']['codeCheck'] = 1
                res['data']['hasSignUp'] = 0
        else:
            res['status'] = 0
            res['data']['result'] = 1
            res['data']['codeCheck'] = 1
            res['data']['hasSignUp'] = 1
        return HttpResponse(json.dumps(res), content_type="application/json")
    else:
        res = {'status': 1, 'data': ''}
        return HttpResponse(json.dumps(res), content_type="application/json")


def getEmailCode(request):
    if request.method == 'POST':
        # the email of user
        toEmail = request.POST['email']
        code = sendEmail.sendCheckCode(toEmail)
        # check the user whether is sign up,0:has,1:hasn't
        status = user.checkUser(toEmail, 'email')
        if code:  # send email success
            res = {'status': 0, 'data': {'hasSignUp': status}}
        else:  # send email failed
            res = {'status': 1, 'data': {'hasSignUp': status}}
        data = {"hasSignUp": status, "code": code}
        session_key = session.setSession(data)  # store the session key
        if session_key:
            res['session_key'] = session_key  # return the session key
        else:
            res['status'] = 1
        return HttpResponse(json.dumps(res, ensure_ascii=False), content_type="application/json")
    else:
        res = {'status': 1, 'data': ''}
        return HttpResponse(json.dumps(res), content_type="application/json")


def modifyInfo(request):
    res = {'status': 1, 'data': ''}
    if request.method == 'POST':
        try:
            user_id = session.getSession(request.POST['user_id'])['user_id']
            logo = request.FILES['logo']
        except:
            logo = ''
            user_id = request.POST['user_id']
        if user_id:
            if logo:  # modify logo
                modifyRes = user.modifyLogo(user_id, logo)
                if modifyRes:
                    res = {'status': 0, 'data': {'result': 0,
                                                 'url': modifyRes}}
                else:
                    res = {'status': 0, 'data': {'result': 1}}
            else:
                userInfo = {}
                userInfo['univercity_id'] = request.POST['univercity_id']
                userInfo['user_tel'] = request.POST['user_tel']
                userInfo['user_qq'] = request.POST['user_qq']
                userInfo['user_id'] = user_id
                userInfo['user_adress'] = request.POST['user_adress']
                incode = request.POST['code']
                try:
                    checkCode = session.getSession(
                        request.POST['session_key'])['code']
                    if incode != checkCode:
                        res = {'status': 0, 'data': {'result': 1}}
                    else:
                        if user.modifyInfo(userInfo):
                            res = {'status': 0, 'data': {'result': 0}}
                        else:
                            res = {'status': 0, 'data': {'result': 3}}
                except:
                    res = {'status': 0, 'data': {'result': 1}}
        else:
            res = {'status': 0, 'data': {'result': 2}}
        return HttpResponse(json.dumps(res, ensure_ascii=False), content_type="application/json")
    else:
        return HttpResponse(json.dumps(res), content_type="application/json")


def getUserInfo(request):
    if request.method == 'POST':
        user_id = session.getSession(request.POST['user_id'])['user_id']
        if user_id:  # get user's infomation
            infoRes = user.getUserInfo(user_id)
            if infoRes:
                res = {'status': 0, 'data': infoRes}
            else:
                res = {'status': 1, 'data': ''}
        else:
            res = {'status': 1, 'data': ''}
        return HttpResponse(json.dumps(res, ensure_ascii=False), content_type="application/json")
    else:
        res = {'status': 1, 'data': {'result': 1}}
        return HttpResponse(json.dumps(res), content_type="application/json")
