from django.db import models
from public import models as public


class TUser(models.Model):
    # Field name made lowercase.
    user_id = models.CharField(
        db_column='USER_ID', primary_key=True, max_length=50)
    # Field name made lowercase.
    user_logo = models.CharField(db_column='USER_LOGO', max_length=200)
    # Field name made lowercase.
    user_name = models.CharField(db_column='USER_NAME', max_length=20)
    # Field name made lowercase.
    name = models.CharField(db_column='NAME', max_length=20)
    # Field name made lowercase.
    user_passwd = models.CharField(db_column='USER_PASSWD', max_length=50)
    # Field name made lowercase.
    user_tel = models.CharField(db_column='USER_TEL', max_length=11)
    # Field name made lowercase.
    user_email = models.CharField(db_column='USER_EMAIL', max_length=50)
    # Field name made lowercase.
    user_qq = models.CharField(
        db_column='USER_QQ', max_length=10, blank=True, null=True)
    # Field name made lowercase.
    user_adress = models.CharField(
        db_column='USER_ADRESS', max_length=50, blank=True, null=True)
    # Field name made lowercase.
    univercity = models.ForeignKey(
        public.TUnivercity, models.DO_NOTHING, db_column='UNIVERCITY_ID')
    # Field name made lowercase. This field type is a guess.
    is_manager = models.TextField(db_column='IS_MANAGER')

    class Meta:
        managed = False
        db_table = 't_user'
