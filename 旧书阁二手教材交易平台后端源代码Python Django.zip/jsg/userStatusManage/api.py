from django.conf import settings
from public import crypt
from public import re
from public import queryToJson as toJson
from public import file
from public import cosFile
from public import getUnivercitys as getU
from public import models as public
from userStatusManage import models
import pymysql
import random
import string
import time
import os
import json


def getUnivercitys():
    res = {}
    data = getU.getUnivercitys()
    if len(data) != 0:
        res['status'] = 0
        res['data'] = data
    else:
        res['status'] = 1
    return res


def getUnivercityById(id):
    univercitys = getUnivercitys()
    if univercitys['status'] == 0:
        for item in univercitys['data']:
            if id == item['id']:
                return item['name']
    else:
        return ''


def checkUser(value, by):
    if by == 'email':
        data = models.TUser.objects.filter(user_email=value)
    elif by == 'user_id':
        data = models.TUser.objects.filter(user_id=value)
    elif by == 'username':
        data = models.TUser.objects.filter(user_name=value)
    res = toJson.getJson(data)
    if len(res) == 0:
        return 1
    else:
        return 0


def signUp(userInfo):
    userInfo['user_id'] = getUserId()
    try:
        models.TUser.objects.create(user_id=userInfo['user_id'], user_logo=userInfo['user_logo'], user_name=userInfo['user_name'], name=userInfo['name'],
                                    user_passwd=userInfo['user_passwd'], user_tel=userInfo[
                                        'user_tel'], user_email=userInfo['user_email'], user_qq=userInfo['user_qq'],
                                    univercity_id=userInfo['univercity_id'], is_manager=1)
        return True
    except:
        return False


def logIn(username, passwd):
    if re.checkEmail(username):
        data = models.TUser.objects.filter(
            user_email=username, user_passwd=passwd).values()
    else:
        data = models.TUser.objects.filter(
            user_name=username, user_passwd=passwd).values()
    if len(data) == 0:
        return False
    else:
        return data[0]['user_id']


def modifyPasswd(email, newPasswd):
    try:
        models.TUser.objects.filter(
            user_email=email).update(user_passwd=newPasswd)
        return True
    except:
        return False


def modifyInfo(userInfo):
    try:
        models.TUser.objects.filter(
            user_id=userInfo['user_id']).update(user_tel=userInfo[
                'user_tel'], user_qq=userInfo['user_qq'], univercity_id=userInfo['univercity_id'], user_adress=userInfo['user_adress'])
        return True
    except:
        return False


def modifyLogo(user_id, logo):
    filename = str(time.time()).split(
        '.')[0] + str(random.randint(0, 10000)) + '.jpg'
    try:
        if file.setFile(filename, logo) == 0:
            user_logo = models.TUser.objects.filter(
                user_id=user_id).values()[0]['user_logo']
            oldpath = 'JSG/user/logo/' + user_logo.split('/')[-1]
            cosFile.delete(oldpath)
            path = 'JSG/user/logo/' + filename
            url = cosFile.up(file.getFile(filename), path)
            models.TUser.objects.filter(
                user_id=user_id).update(user_logo=url)
            return url
        else:
            return False
    except:
        return False
    finally:
        if(os.path.exists(filename)):
            os.remove(filename)


def getUserInfo(user_id):
    try:
        userInfo = models.TUser.objects.filter(
            user_id=user_id).values('user_id', 'user_name', 'name', 'user_tel', 'user_email', 'user_qq', "user_adress", 'user_logo', 'univercity_id')
        if len(userInfo) == 1:
            userInfo[0]['univercity'] = public.TUnivercity.objects.filter(
                univercity_id=userInfo[0]['univercity_id']).values()[0]['univercity_name']
            return userInfo[0]
        else:
            return False
    except:
        return False


def getUserId():
    return ''.join(random.sample(string.ascii_letters + string.digits, 10))
