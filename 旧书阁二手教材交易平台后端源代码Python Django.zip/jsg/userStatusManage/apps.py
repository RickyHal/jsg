from django.apps import AppConfig


class UserstatusmanageConfig(AppConfig):
    name = 'userStatusManage'
