from shareBookManage import models
from userStatusManage import models as user
from django.db.models import Q
from public import queryToJson as toJson
from public import file
from public import cosFile
import json
import os
import time
import datetime
import uuid
import random


def upShareImgs(img):
    filename = str(time.time()).split(
        '.')[0] + str(random.randint(0, 10000)) + '.jpg'
    try:
        if file.setFile(filename, img) == 0:
            path = 'JSG/user/shareBook/imgs/' + filename
            url = cosFile.up(file.getFile(filename), path)
            return url
        else:
            return False
    except:
        return False
    finally:
        if(os.path.exists(filename)):
            os.remove(filename)


def modifyShareInfo(shareInfo):
    try:
        models.TShareBook.objects.filter(
            share_id=shareInfo['share_id']).update(book_name=shareInfo['book_name'], book_author=shareInfo['book_author'],
                                                   book_isbn=shareInfo[
                                                       'book_isbn'], book_imgs=shareInfo['imgs'],
                                                   canborrowtime_begin=shareInfo[
                'canBorrowTime_begin'], canborrowtime_end=shareInfo['canBorrowTime_end'],
            share_marks=shareInfo['marks'])
        return True
    except:
        return False


def addShareInfo(shareInfo):
    try:
        models.TShareBook.objects.create(user_id=shareInfo['user_id'],
                                         share_id=str(time.time()).split('.')[
            0] + str(random.randint(0, 10000)), book_name=shareInfo['book_name'],
            book_author=shareInfo['book_author'], book_isbn=shareInfo[
                'book_isbn'], book_imgs=shareInfo['imgs'],
            canborrowtime_begin=datetime.datetime.strptime(
                shareInfo['canBorrowTime_begin'], '%Y-%m-%d'),
            canborrowtime_end=datetime.datetime.strptime(shareInfo[
                'canBorrowTime_end'], '%Y-%m-%d'),
            share_marks=shareInfo['marks'], status=1)
        return True
    except:
        return False


def getMyShareInfo(user_id):
    try:
        data = models.TShareBook.objects.filter(
            user_id=user_id).values().order_by('-release_time')
        res = toJson.getJson(data)
        for item in res:
            item['release_time'] = item['release_time'].strftime('%Y-%m-%d')
            item['canborrowtime_begin'] = item[
                'canborrowtime_begin'].strftime('%Y-%m-%d')
            item['canborrowtime_end'] = item[
                'canborrowtime_end'].strftime('%Y-%m-%d')
            imgs = []
            for img in (item['book_imgs']).split(' '):
                if img != '':
                    imgs.append(img)
            item['book_imgs'] = imgs
            item['wannerBorrowNum'] = models.TBookBorrowRec.objects.filter(
                share_id=item['share_id']).count()
        return res
    except:
        return False


def upDownBook(share_id, flag):
    try:
        models.TShareBook.objects.filter(
            share_id=share_id).update(status=flag)
        return True
    except:
        return False


def deleteShareBook(share_id):
    try:
        models.TShareBook.objects.filter(
            share_id=share_id).delete()
        return True
    except:
        return False


def getShareList(page, key):
    try:
        if key.strip() != '':
            data = models.TShareBook.objects.filter((Q(book_name__icontains=key) | Q(
                book_isbn__icontains=key) | Q(book_author__icontains=key)), status='1').values()[int(page):int(page) + 10]
        else:
            data = models.TShareBook.objects.filter(status='1').values()[
                int(page):int(page) + 10]
        for item in data:
            item['release_time'] = item['release_time'].strftime('%Y-%m-%d')
            item['canborrowtime_begin'] = item[
                'canborrowtime_begin'].strftime('%Y-%m-%d')
            item['canborrowtime_end'] = item[
                'canborrowtime_end'].strftime('%Y-%m-%d')
            imgs = []
            for img in (item['book_imgs']).split(' '):
                if img != '':
                    imgs.append(img)
            item['book_imgs'] = imgs
            item['share_person'] = user.TUser.objects.filter(
                user_id=item['user_id']).values('name')[0]['name']
        res = toJson.getJson(data)
        return res
    except:
        return False


def getShareBookDetail(share_id, book_isbn, user_id):
    print(user_id, share_id, book_isbn)
    try:
        data = models.TShareBook.objects.filter(
            Q(share_id=share_id) | Q(book_isbn=book_isbn)).values()
        for item in data:
            item['release_time'] = item['release_time'].strftime('%Y-%m-%d')
            item['canborrowtime_begin'] = item[
                'canborrowtime_begin'].strftime('%Y-%m-%d')
            item['canborrowtime_end'] = item[
                'canborrowtime_end'].strftime('%Y-%m-%d')
            imgs = []
            for img in (item['book_imgs']).split(' '):
                if img != '':
                    imgs.append(img)
            item['book_imgs'] = imgs
            item['from'] = user.TUser.objects.filter(
                user_id=item['user_id']).values('name', 'user_tel', 'user_logo', 'user_qq')[0]
            item['hasBorrow'] = 0
            if models.TBookBorrowRec.objects.filter(user_id=user_id, share_id=item['share_id']).values():
                item['hasBorrow'] = 1
            return item
    except:
        return False


def borrow(share_id, user_id):
    try:
        models.TBookBorrowRec.objects.create(id=uuid.uuid4(),
                                             share_id=str(share_id), user_id=user_id)
        return True
    except:
        return False


def getBorrowRec(share_id):
    rec = models.TBookBorrowRec.objects.filter(
        share_id=share_id).values('user_id')
    user_id = []
    for item in rec:
        user_id.append(item['user_id'])
    res = []
    for item in user_id:
        u = list(user.TUser.objects.filter(user_id=item).values(
            'user_id', 'user_name', 'user_logo', 'user_tel', 'user_qq'))
        res.append(u[0])
    return res
