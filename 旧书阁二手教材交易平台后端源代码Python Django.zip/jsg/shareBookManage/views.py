from django.shortcuts import render
from django.http import HttpResponse
from public import session
from shareBookManage import api as shareBook
import json
# Create your views here.


def upShareImgs(request):
    if request.method == 'POST':
        img = request.FILES['img']
        print(img.size)
        if img:
            src = shareBook.upShareImgs(img)
            if src:
                res = {'status': 0, 'data': {'src': src}}
            else:
                res = {'status': 0, 'data': {'src': 1}}
        else:
            res = {'status': 0, 'data': {'src': 1}}
        return HttpResponse(json.dumps(res, ensure_ascii=False), content_type="application/json")
    else:
        res = {'status': 1}
        return HttpResponse(json.dumps(res), content_type="application/json")


def amShareBook(request):
    if request.method == 'POST':
        shareInfo = {}
        try:
            shareInfo['share_id'] = request.POST['share_id']
        except:
            shareInfo['share_id'] = ''
        try:
            shareInfo['user_id'] = session.getSession(
                request.POST['user_id'])['user_id']
        except:
            shareInfo['user_id'] = request.POST['user_id']
        shareInfo['imgs'] = request.POST['imgs']
        shareInfo['book_name'] = request.POST['book_name']
        shareInfo['book_author'] = request.POST['book_author']
        shareInfo['book_isbn'] = request.POST['book_isbn']
        shareInfo['canBorrowTime_begin'] = request.POST['canBorrowTime_begin']
        shareInfo['canBorrowTime_end'] = request.POST['canBorrowTime_end']
        shareInfo['marks'] = request.POST['marks']
        print(shareInfo)
        if shareInfo['user_id']:
            if shareInfo['share_id'] != '-1':
                print(shareInfo['share_id'])
                mRes = shareBook.modifyShareInfo(shareInfo)
                if mRes:
                    res = {'status': 0, 'data': {'type': 0, 'result': 0}}
                else:
                    res = {'status': 0, 'data': {'type': 0, 'result': 1}}
            else:
                addRes = shareBook.addShareInfo(shareInfo)
                if addRes:
                    res = {'status': 0, 'data': {'type': 1, 'result': 0}}
                else:
                    res = {'status': 0, 'data': {'type': 1, 'result': 1}}
        else:
            res = {'status': 0, 'data': ''}
        print(res)
        return HttpResponse(json.dumps(res, ensure_ascii=False), content_type="application/json")
    else:
        res = {'status': 1}
        return HttpResponse(json.dumps(res), content_type="application/json")


def getMyShareInfo(request):
    if request.method == 'POST':
        user_id = request.POST['user_id']
        if user_id:
            data = shareBook.getMyShareInfo(user_id)
            if data:
                res = {'status': 0, 'data': data}
            else:
                res = {'status': 0, 'data': []}
        else:
            res = {'status': 0, 'data': {'result': 1}}
        return HttpResponse(json.dumps(res, ensure_ascii=False), content_type="application/json")
    else:
        res = {'status': 1}
        return HttpResponse(json.dumps(res), content_type="application/json")


def shareManage(request):
    if request.method == 'POST':
        flag = request.POST['flag']
        share_id = request.POST['share_id']
        print(flag + '   ' + share_id)
        if share_id:
            if flag == '0' or flag == '1':
                udRes = shareBook.upDownBook(share_id, flag)
                if udRes:
                    res = {'status': 0, 'data': {'result': 0}}
                else:
                    res = {'status': 0, 'data': {'result': 1}}
            else:
                deleteRes = shareBook.deleteShareBook(share_id)
                if deleteRes:
                    res = {'status': 0, 'data': {'result': 0}}
                else:
                    res = {'status': 0, 'data': {'result': 1}}
        else:
            res = {'status': 0, 'data': {'result': 1}}
        print(res)
        return HttpResponse(json.dumps(res, ensure_ascii=False), content_type="application/json")
    else:
        res = {'status': 1}
        return HttpResponse(json.dumps(res), content_type="application/json")


def getShareList(request):
    if request.method == 'POST':
        key = request.POST['key']
        page = request.POST['page']
        if page:
            data = shareBook.getShareList(page, key)
            if data:
                res = {'status': 0, 'data': data}
            else:
                res = {'status': 0, 'data': []}
        else:
            res = {'status': 0, 'data': []}
        return HttpResponse(json.dumps(res, ensure_ascii=False), content_type="application/json")
    else:
        res = {'status': 1}
        return HttpResponse(json.dumps(res), content_type="application/json")


def getShareBookDetail(request):
    if request.method == 'POST':
        share_id = request.POST['share_id']
        book_isbn = request.POST['book_isbn']
        user_id = request.POST['user_id']
        print(book_isbn)
        if share_id or book_isbn:
            user_id = session.getSession(user_id)['user_id']
            data = shareBook.getShareBookDetail(share_id, book_isbn, user_id)
            if data:
                res = {'status': 0, 'data': data}
            else:
                res = {'status': 0, 'data': ''}
        else:
            res = {'status': 0, 'data': ''}
        print(res)
        return HttpResponse(json.dumps(res, ensure_ascii=False), content_type="application/json")
    else:
        res = {'status': 1}
        return HttpResponse(json.dumps(res), content_type="application/json")


def borrow(request):
    if request.method == 'POST':
        share_id = request.POST['share_id']
        user_id = request.POST['user_id']
        if share_id:
            user_id = session.getSession(user_id)['user_id']
            data = shareBook.borrow(share_id, user_id)
            if data:
                res = {'status': 0, }
            else:
                res = {'status': 0}
        else:
            res = {'status': 0}
        return HttpResponse(json.dumps(res, ensure_ascii=False), content_type="application/json")
    else:
        res = {'status': 1}
        return HttpResponse(json.dumps(res), content_type="application/json")


def getBorrowRec(request):
    if request.method == 'POST':
        share_id = request.POST['share_id']
        if share_id:
            data = shareBook.getBorrowRec(share_id)
            if data:
                res = {'status': 0, 'data': data}
            else:
                res = {'status': 0, 'data': []}
        else:
            res = {'status': 0, 'data': []}
        return HttpResponse(json.dumps(res, ensure_ascii=False), content_type="application/json")
    else:
        res = {'status': 1}
        return HttpResponse(json.dumps(res), content_type="application/json")
