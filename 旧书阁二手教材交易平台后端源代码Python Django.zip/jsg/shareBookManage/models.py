from django.db import models
from userStatusManage import models as user
# Create your models here.


class TShareBook(models.Model):
    # Field name made lowercase.
    share_id = models.CharField(
        db_column='SHARE_ID', primary_key=True, max_length=20)
    # Field name made lowercase.
    book_name = models.CharField(
        db_column='BOOK_NAME', max_length=50, blank=True, null=True)
    # Field name made lowercase.
    book_isbn = models.CharField(
        db_column='BOOK_ISBN', max_length=13, blank=True, null=True)
    # Field name made lowercase.
    user = models.ForeignKey(
        user.TUser, models.DO_NOTHING, db_column='USER_ID')
    # Field name made lowercase.
    book_imgs = models.CharField(
        db_column='BOOK_IMGS', max_length=1000, blank=True, null=True)
    # Field name made lowercase.
    release_time = models.DateTimeField(
        db_column='RELEASE_TIME', auto_now_add=True)
    # Field name made lowercase.
    canborrowtime_begin = models.DateTimeField(db_column='CANBORROWTIME_BEGIN')
    # Field name made lowercase.
    canborrowtime_end = models.DateTimeField(db_column='CANBORROWTIME_END')
    # Field name made lowercase.
    share_marks = models.CharField(
        db_column='SHARE_MARKS', max_length=300, blank=True, null=True)
    # Field name made lowercase.
    status = models.IntegerField(db_column='STATUS')
    # Field name made lowercase.
    book_author = models.CharField(db_column='BOOK_AUTHOR', max_length=100)

    class Meta:
        managed = False
        db_table = 't_share_book'


class TBookBorrowRec(models.Model):
    # Field name made lowercase.
    id = models.CharField(db_column='ID', primary_key=True, max_length=36)
    # Field name made lowercase.
    share = models.ForeignKey(
        'TShareBook', models.DO_NOTHING, db_column='SHARE_ID')
    # Field name made lowercase.
    user = models.ForeignKey(
        user.TUser, models.DO_NOTHING, db_column='USER_ID')
    # Field name made lowercase.
    borrow_time = models.DateTimeField(db_column='BORROW_TIME', auto_now=True)

    class Meta:
        managed = False
        db_table = 't_book_borrow_rec'
