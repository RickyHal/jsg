from django.apps import AppConfig


class SharebookmanageConfig(AppConfig):
    name = 'shareBookManage'
