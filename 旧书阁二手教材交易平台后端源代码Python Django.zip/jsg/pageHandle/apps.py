from django.apps import AppConfig


class PagehandleConfig(AppConfig):
    name = 'pageHandle'
