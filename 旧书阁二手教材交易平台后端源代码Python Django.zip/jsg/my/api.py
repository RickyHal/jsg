from my import models
from public import queryToJson as toJson
import pymysql
import random
import string
import time
import datetime
import json


def appoint(appointInfo):
    try:
        models.TAppointment.objects.create(
            appointment_id=str(time.time()).split('.')[0] + str(random.randint(0, 10000)), appointment_status=1, user_id=appointInfo['user_id'],
            user_name=appointInfo['contact'], user_tel=appointInfo[
                'tel'], user_qq=appointInfo['qq'], appointment_adress=appointInfo['adress'],
            appointment_up_time=appointInfo['upDoorDate'] + ' ' + appointInfo['upDoorTime'], appointment_num=appointInfo['book_num'],
            appointment_cell=appointInfo['book_cell'])
        return True
    except:
        return False


def getAppointments(user_id):
    data = models.TAppointment.objects.filter(user_id=user_id).values()
    appointments = toJson.getJson(data)
    res = []
    for item in appointments:
        appointment = {}
        appointment['appointmentId'] = item['appointment_id']
        appointment['status'] = item['appointment_status']
        appointment['appointmentInfo'] = {}
        appointment['appointmentInfo']['user_id'] = item['user_id']
        appointment['appointmentInfo'][
            'appointmentName'] = item['user_name']
        appointment['appointmentInfo'][
            'appointmentTel'] = item['user_tel']
        appointment['appointmentInfo'][
            'appointmentQQ'] = item['user_qq']
        appointment['appointmentInfo'][
            'appointmentAdress'] = item['appointment_adress']
        appointment['appointmentInfo'][
            'appointmentTime'] = item['appointment_time'].strftime('%Y-%m-%d %H:%I:%S')
        appointment['appointmentInfo'][
            'appointmentUPTime'] = item['appointment_up_time'].strftime('%Y-%m-%d %H:%I:%S')
        appointment['appointmentInfo'][
            'appointmentNum'] = item['appointment_num']
        appointment['appointmentInfo'][
            'appointmentCell'] = item['appointment_cell']
        appointment['upDoorInfo'] = {}
        if item['send_user_id']:
            appointment['upDoorInfo']['upDoorUserId'] = item['send_user_id']
            appointment['upDoorInfo']['upDoorName'] = item['updoor_name']
            appointment['upDoorInfo']['upDoorTel'] = item['updoor_tel']
            appointment['upDoorInfo']['upDoorQQ'] = item['updoor_qq']
            appointment['upDoorInfo']['upDoorTime'] = item[
                'updoor_time'].strftime('%Y-%m-%d %H:%I:%S')
            appointment['upDoorInfo']['upDoorNum'] = item['updoor_num']
            appointment['upDoorInfo']['upDoorCell'] = item['updoor_cell']
        res.append(appointment)
    return res


def cancelAppointment(appointment_id):
    try:
        models.TAppointment.objects.filter(
            appointment_id=appointment_id).delete()
        return True
    except:
        return False
