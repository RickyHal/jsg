from django.db import models
from userStatusManage import models as user
# Create your models here.


class TAppointment(models.Model):
    # Field name made lowercase.
    appointment_id = models.CharField(
        db_column='APPOINTMENT_ID', primary_key=True, max_length=20)
    # Field name made lowercase.
    appointment_status = models.IntegerField(db_column='APPOINTMENT_STATUS')
    # Field name made lowercase.
    user = models.ForeignKey(
        user.TUser, models.DO_NOTHING, db_column='USER_ID')
    # Field name made lowercase.
    user_name = models.CharField(db_column='USER_NAME', max_length=20)
    # Field name made lowercase.
    user_tel = models.CharField(db_column='USER_TEL', max_length=11)
    # Field name made lowercase.
    user_qq = models.CharField(
        db_column='USER_QQ', max_length=10, blank=True, null=True)
    # Field name made lowercase.
    appointment_adress = models.CharField(
        db_column='APPOINTMENT_ADRESS', max_length=50)
    # Field name made lowercase.
    appointment_time = models.DateTimeField(
        db_column='APPOINTMENT_TIME', auto_now_add=True)
    # Field name made lowercase.
    appointment_up_time = models.DateTimeField(db_column='APPOINTMENT_UP_TIME')
    # Field name made lowercase.
    appointment_num = models.IntegerField(db_column='APPOINTMENT_NUM')
    # Field name made lowercase.
    appointment_cell = models.CharField(
        db_column='APPOINTMENT_CELL', max_length=1)
    # Field name made lowercase.
    send_user_id = models.CharField(
        db_column='SEND_USER_ID', max_length=50, blank=True, null=True)
    # Field name made lowercase.
    updoor_time = models.DateTimeField(
        db_column='UPDOOR_TIME', blank=True, null=True)
    # Field name made lowercase.
    updoor_num = models.IntegerField(
        db_column='UPDOOR_NUM', blank=True, null=True)
    # Field name made lowercase.
    updoor_cell = models.CharField(
        db_column='UPDOOR_CELL', max_length=1, blank=True, null=True)
    # Field name made lowercase.
    updoor_qq = models.CharField(
        db_column='UPDOOR_QQ', max_length=10, blank=True, null=True)
    # Field name made lowercase.
    updoor_tel = models.CharField(
        db_column='UPDOOR_TEL', max_length=11, blank=True, null=True)
    # Field name made lowercase.
    updoor_name = models.CharField(
        db_column='UPDOOR_NAME', max_length=10, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 't_appointment'


class TOrderDetail(models.Model):
    # Field name made lowercase.
    order = models.ForeignKey(
        'TOrderRec', models.DO_NOTHING, db_column='ORDER_ID', primary_key=True)
    # Field name made lowercase.
    book_id = models.CharField(db_column='BOOK_ID', max_length=20)
    # Field name made lowercase.
    book_new = models.IntegerField(db_column='BOOK_NEW')
    # Field name made lowercase.
    book_num = models.IntegerField(db_column='BOOK_NUM')
    # Field name made lowercase.
    total_price = models.DecimalField(
        db_column='TOTAL_PRICE', max_digits=4, decimal_places=2)

    class Meta:
        managed = False
        db_table = 't_order_detail'
        unique_together = (('order', 'book_id'),)


class TOrderRec(models.Model):
    # Field name made lowercase.
    order_id = models.CharField(
        db_column='ORDER_ID', primary_key=True, max_length=50)
    # Field name made lowercase.
    order_time = models.DateTimeField(db_column='ORDER_TIME')
    # Field name made lowercase.
    order_status = models.IntegerField(db_column='ORDER_STATUS')
    # Field name made lowercase.
    user = models.ForeignKey(
        user.TUser, models.DO_NOTHING, db_column='USER_ID')

    class Meta:
        managed = False
        db_table = 't_order_rec'


class TReceiveInfo(models.Model):
    # Field name made lowercase.
    order = models.ForeignKey(
        TOrderRec, models.DO_NOTHING, db_column='ORDER_ID', primary_key=True)
    # Field name made lowercase.
    send_time = models.DateTimeField(db_column='SEND_TIME')
    # Field name made lowercase.
    reveive_person = models.CharField(
        db_column='REVEIVE_PERSON', max_length=20)
    # Field name made lowercase.
    reveive_tel = models.CharField(db_column='REVEIVE_TEL', max_length=11)
    # Field name made lowercase.
    reveive_qq = models.CharField(
        db_column='REVEIVE_QQ', max_length=10, blank=True, null=True)
    # Field name made lowercase.
    reveive_adress = models.CharField(
        db_column='REVEIVE_ADRESS', max_length=50)

    class Meta:
        managed = False
        db_table = 't_receive_info'


class TSendInfo(models.Model):
    # Field name made lowercase.
    order = models.ForeignKey(
        TOrderRec, models.DO_NOTHING, db_column='ORDER_ID', primary_key=True)
    # Field name made lowercase.
    send_person_id = models.CharField(
        db_column='SEND_PERSON_ID', max_length=50)
    # Field name made lowercase.
    receive_time = models.DateTimeField(
        db_column='RECEIVE_TIME', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 't_send_info'
