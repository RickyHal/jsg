# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class AuthGroup(models.Model):
    name = models.CharField(unique=True, max_length=80)

    class Meta:
        managed = False
        db_table = 'auth_group'


class AuthGroupPermissions(models.Model):
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)
    permission = models.ForeignKey('AuthPermission', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_group_permissions'
        unique_together = (('group', 'permission'),)


class AuthPermission(models.Model):
    name = models.CharField(max_length=255)
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING)
    codename = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'auth_permission'
        unique_together = (('content_type', 'codename'),)


class AuthUser(models.Model):
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.IntegerField()
    username = models.CharField(unique=True, max_length=150)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=150)
    email = models.CharField(max_length=254)
    is_staff = models.IntegerField()
    is_active = models.IntegerField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'


class AuthUserGroups(models.Model):
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_groups'
        unique_together = (('user', 'group'),)


class AuthUserUserPermissions(models.Model):
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    permission = models.ForeignKey(AuthPermission, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_user_permissions'
        unique_together = (('user', 'permission'),)


class DjangoAdminLog(models.Model):
    action_time = models.DateTimeField()
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=200)
    action_flag = models.PositiveSmallIntegerField()
    change_message = models.TextField()
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING, blank=True, null=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=40)
    session_data = models.TextField()
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'


class TAppointment(models.Model):
    appointment_id = models.CharField(db_column='APPOINTMENT_ID', primary_key=True, max_length=20)  # Field name made lowercase.
    appointment_status = models.IntegerField(db_column='APPOINTMENT_STATUS')  # Field name made lowercase.
    user = models.ForeignKey('TUser', models.DO_NOTHING, db_column='USER_ID')  # Field name made lowercase.
    user_name = models.CharField(db_column='USER_NAME', max_length=20)  # Field name made lowercase.
    user_tel = models.CharField(db_column='USER_TEL', max_length=11)  # Field name made lowercase.
    user_qq = models.CharField(db_column='USER_QQ', max_length=10, blank=True, null=True)  # Field name made lowercase.
    appointment_adress = models.CharField(db_column='APPOINTMENT_ADRESS', max_length=50)  # Field name made lowercase.
    appointment_time = models.DateTimeField(db_column='APPOINTMENT_TIME')  # Field name made lowercase.
    appointment_up_time = models.DateTimeField(db_column='APPOINTMENT_UP_TIME')  # Field name made lowercase.
    appointment_num = models.IntegerField(db_column='APPOINTMENT_NUM')  # Field name made lowercase.
    appointment_cell = models.CharField(db_column='APPOINTMENT_CELL', max_length=1)  # Field name made lowercase.
    send_user_id = models.CharField(db_column='SEND_USER_ID', max_length=50, blank=True, null=True)  # Field name made lowercase.
    updoor_time = models.DateTimeField(db_column='UPDOOR_TIME', blank=True, null=True)  # Field name made lowercase.
    updoor_num = models.IntegerField(db_column='UPDOOR_NUM', blank=True, null=True)  # Field name made lowercase.
    updoor_cell = models.CharField(db_column='UPDOOR_CELL', max_length=1, blank=True, null=True)  # Field name made lowercase.
    updoor_qq = models.CharField(db_column='UPDOOR_QQ', max_length=10, blank=True, null=True)  # Field name made lowercase.
    updoor_tel = models.CharField(db_column='UPDOOR_TEL', max_length=11, blank=True, null=True)  # Field name made lowercase.
    updoor_name = models.CharField(db_column='UPDOOR_NAME', max_length=10, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 't_appointment'


class TBook(models.Model):
    book_id = models.CharField(db_column='BOOK_ID', primary_key=True, max_length=20)  # Field name made lowercase.
    book_isbn = models.CharField(db_column='BOOK_ISBN', max_length=13)  # Field name made lowercase.
    book_name = models.CharField(db_column='BOOK_NAME', max_length=50)  # Field name made lowercase.
    book_img = models.CharField(db_column='BOOK_IMG', max_length=200)  # Field name made lowercase.
    book_type = models.ForeignKey('TBookTypes', models.DO_NOTHING, db_column='BOOK_TYPE_ID', blank=True, null=True)  # Field name made lowercase.
    book_type_id_child = models.CharField(db_column='BOOK_TYPE_ID_CHILD', max_length=4)  # Field name made lowercase.
    book_author = models.CharField(db_column='BOOK_AUTHOR', max_length=50)  # Field name made lowercase.
    book_publisher = models.CharField(db_column='BOOK_PUBLISHER', max_length=50)  # Field name made lowercase.
    book_publish_year = models.CharField(db_column='BOOK_PUBLISH_YEAR', max_length=20)  # Field name made lowercase.
    book_introduce = models.CharField(db_column='BOOK_INTRODUCE', max_length=10000, blank=True, null=True)  # Field name made lowercase.
    book_content = models.CharField(db_column='BOOK_CONTENT', max_length=10000, blank=True, null=True)  # Field name made lowercase.
    book_price = models.DecimalField(db_column='BOOK_PRICE', max_digits=4, decimal_places=2)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 't_book'


class TBookBorrowRec(models.Model):
    share = models.ForeignKey('TShareBook', models.DO_NOTHING, db_column='SHARE_ID', primary_key=True)  # Field name made lowercase.
    user = models.ForeignKey('TUser', models.DO_NOTHING, db_column='USER_ID')  # Field name made lowercase.
    borrow_time = models.DateTimeField(db_column='BORROW_TIME')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 't_book_borrow_rec'


class TBookTypes(models.Model):
    book_type_id = models.CharField(db_column='BOOK_TYPE_ID', primary_key=True, max_length=4)  # Field name made lowercase.
    type_name = models.CharField(db_column='TYPE_NAME', max_length=20)  # Field name made lowercase.
    parent_id = models.CharField(db_column='PARENT_ID', max_length=4, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 't_book_types'


class TOrderDetail(models.Model):
    order = models.ForeignKey('TOrderRec', models.DO_NOTHING, db_column='ORDER_ID', primary_key=True)  # Field name made lowercase.
    book_id = models.CharField(db_column='BOOK_ID', max_length=20)  # Field name made lowercase.
    book_new = models.IntegerField(db_column='BOOK_NEW')  # Field name made lowercase.
    book_num = models.IntegerField(db_column='BOOK_NUM')  # Field name made lowercase.
    total_price = models.DecimalField(db_column='TOTAL_PRICE', max_digits=4, decimal_places=2)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 't_order_detail'
        unique_together = (('order', 'book_id'),)


class TOrderRec(models.Model):
    order_id = models.CharField(db_column='ORDER_ID', primary_key=True, max_length=50)  # Field name made lowercase.
    order_time = models.DateTimeField(db_column='ORDER_TIME')  # Field name made lowercase.
    order_status = models.IntegerField(db_column='ORDER_STATUS')  # Field name made lowercase.
    user = models.ForeignKey('TUser', models.DO_NOTHING, db_column='USER_ID')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 't_order_rec'


class TReceiveInfo(models.Model):
    order = models.ForeignKey(TOrderRec, models.DO_NOTHING, db_column='ORDER_ID', primary_key=True)  # Field name made lowercase.
    send_time = models.DateTimeField(db_column='SEND_TIME')  # Field name made lowercase.
    reveive_person = models.CharField(db_column='REVEIVE_PERSON', max_length=20)  # Field name made lowercase.
    reveive_tel = models.CharField(db_column='REVEIVE_TEL', max_length=11)  # Field name made lowercase.
    reveive_qq = models.CharField(db_column='REVEIVE_QQ', max_length=10, blank=True, null=True)  # Field name made lowercase.
    reveive_adress = models.CharField(db_column='REVEIVE_ADRESS', max_length=50)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 't_receive_info'


class TSailBook(models.Model):
    sail_id = models.CharField(db_column='SAIL_ID', primary_key=True, max_length=20)  # Field name made lowercase.
    book = models.ForeignKey(TBook, models.DO_NOTHING, db_column='BOOK_ID')  # Field name made lowercase.
    book_imgs = models.CharField(db_column='BOOK_IMGS', max_length=1000)  # Field name made lowercase.
    book_marks = models.CharField(db_column='BOOK_MARKS', max_length=10, blank=True, null=True)  # Field name made lowercase.
    univercity = models.ForeignKey('TUnivercity', models.DO_NOTHING, db_column='UNIVERCITY_ID')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 't_sail_book'


class TSailBookStock(models.Model):
    stock_id = models.CharField(db_column='STOCK_ID', primary_key=True, max_length=20)  # Field name made lowercase.
    sail = models.ForeignKey(TSailBook, models.DO_NOTHING, db_column='SAIL_ID', blank=True, null=True)  # Field name made lowercase.
    book_new = models.IntegerField(db_column='BOOK_NEW')  # Field name made lowercase.
    book_stock = models.IntegerField(db_column='BOOK_STOCK')  # Field name made lowercase.
    book_price = models.DecimalField(db_column='BOOK_PRICE', max_digits=4, decimal_places=2)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 't_sail_book_stock'


class TSendInfo(models.Model):
    order = models.ForeignKey(TOrderRec, models.DO_NOTHING, db_column='ORDER_ID', primary_key=True)  # Field name made lowercase.
    send_person_id = models.CharField(db_column='SEND_PERSON_ID', max_length=50)  # Field name made lowercase.
    receive_time = models.DateTimeField(db_column='RECEIVE_TIME', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 't_send_info'


class TSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=32)
    time = models.DateTimeField()
    data = models.CharField(max_length=1000)

    class Meta:
        managed = False
        db_table = 't_session'


class TShareBook(models.Model):
    share_id = models.CharField(db_column='SHARE_ID', primary_key=True, max_length=20)  # Field name made lowercase.
    book_name = models.CharField(db_column='BOOK_NAME', max_length=50, blank=True, null=True)  # Field name made lowercase.
    book_isbn = models.CharField(db_column='BOOK_ISBN', max_length=13, blank=True, null=True)  # Field name made lowercase.
    user = models.ForeignKey('TUser', models.DO_NOTHING, db_column='USER_ID')  # Field name made lowercase.
    book_imgs = models.CharField(db_column='BOOK_IMGS', max_length=1000, blank=True, null=True)  # Field name made lowercase.
    release_time = models.DateTimeField(db_column='RELEASE_TIME')  # Field name made lowercase.
    canborrowtime_begin = models.DateField(db_column='CANBORROWTIME_BEGIN')  # Field name made lowercase.
    canborrowtime_end = models.DateField(db_column='CANBORROWTIME_END')  # Field name made lowercase.
    share_marks = models.CharField(db_column='SHARE_MARKS', max_length=300, blank=True, null=True)  # Field name made lowercase.
    status = models.IntegerField(db_column='STATUS')  # Field name made lowercase.
    book_author = models.CharField(db_column='BOOK_AUTHOR', max_length=100)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 't_share_book'


class TShoppingCar(models.Model):
    id = models.CharField(db_column='ID', primary_key=True, max_length=20)  # Field name made lowercase.
    user = models.ForeignKey('TUser', models.DO_NOTHING, db_column='USER_ID')  # Field name made lowercase.
    book = models.ForeignKey(TBook, models.DO_NOTHING, db_column='BOOK_ID')  # Field name made lowercase.
    new = models.IntegerField(db_column='NEW')  # Field name made lowercase.
    num = models.IntegerField(db_column='NUM')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 't_shopping_car'


class TUnivercity(models.Model):
    univercity_id = models.CharField(db_column='UNIVERCITY_ID', primary_key=True, max_length=10)  # Field name made lowercase.
    univercity_name = models.CharField(db_column='UNIVERCITY_NAME', max_length=50)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 't_univercity'


class TUser(models.Model):
    user_id = models.CharField(db_column='USER_ID', primary_key=True, max_length=50)  # Field name made lowercase.
    user_logo = models.CharField(db_column='USER_LOGO', max_length=200)  # Field name made lowercase.
    user_name = models.CharField(db_column='USER_NAME', max_length=20)  # Field name made lowercase.
    name = models.CharField(db_column='NAME', max_length=20)  # Field name made lowercase.
    user_passwd = models.CharField(db_column='USER_PASSWD', max_length=50)  # Field name made lowercase.
    user_tel = models.CharField(db_column='USER_TEL', max_length=11)  # Field name made lowercase.
    user_email = models.CharField(db_column='USER_EMAIL', max_length=50)  # Field name made lowercase.
    user_qq = models.CharField(db_column='USER_QQ', max_length=10, blank=True, null=True)  # Field name made lowercase.
    user_adress = models.CharField(db_column='USER_ADRESS', max_length=50, blank=True, null=True)  # Field name made lowercase.
    univercity = models.ForeignKey(TUnivercity, models.DO_NOTHING, db_column='UNIVERCITY_ID')  # Field name made lowercase.
    is_manager = models.IntegerField(db_column='IS_MANAGER')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 't_user'
