from django.shortcuts import render
from django.http import HttpResponse
from public import session
from my import api as my
import json


def appoint(request):
    if request.method == 'POST':
        appointInfo = {}
        appointInfo['user_id'] = request.POST['user_id']
        appointInfo['book_num'] = request.POST['book_num']
        appointInfo['book_cell'] = request.POST['book_cell']
        appointInfo['upDoorDate'] = request.POST['upDoorDate']
        appointInfo['upDoorTime'] = request.POST['upDoorTime']
        appointInfo['contact'] = request.POST['contact']
        appointInfo['tel'] = request.POST['tel']
        try:
            appointInfo['qq'] = request.POST['qq']
        except:
            appointInfo['qq'] = ''
        appointInfo['adress'] = request.POST['adress']
        print(appointInfo)
        if my.appoint(appointInfo):
            res = {'status': 0, 'data': {'result': 0}}
        else:
            res = {'status': 0, 'data': {'result': 1}}
        print(res)
        return HttpResponse(json.dumps(res, ensure_ascii=False), content_type="application/json")
    else:
        res = {'status': 1}
        return HttpResponse(json.dumps(res), content_type="application/json")


def getAppointments(request):
    if request.method == 'POST':
        user_id = request.POST['user_id']
        data = my.getAppointments(user_id)
        if data:
            res = {'status': 0, 'data': data}
        else:
            res = {'status': 0, 'data': []}
        return HttpResponse(json.dumps(res, ensure_ascii=False), content_type="application/json")
    else:
        res = {'status': 1}
        return HttpResponse(json.dumps(res), content_type="application/json")


def cancelAppointment(request):
    if request.method == 'POST':
        appointment_id = request.POST['appointment_id']
        print(appointment_id)
        if my.cancelAppointment(appointment_id):
            res = {'status': 0, 'data': {'result': 0}}
        else:
            res = {'status': 0, 'data': {'result': 1}}
        return HttpResponse(json.dumps(res, ensure_ascii=False), content_type="application/json")
    else:
        res = {'status': 1}
        return HttpResponse(json.dumps(res), content_type="application/json")
