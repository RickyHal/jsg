import fetch from '@system.fetch'
import prompt from '@system.prompt'

/**
 * filename:book_share.js
 * author:Ricky
 * date:2018/10/27
 * marks:
 * 
 */

/**
 * function:get the information book that others share
 * parameter:
 *  1.that
 * return:
 **/
function getShareInfo(that) {
    that.progressShow = true
    fetch.fetch({
        url: that.hostUrl + "user/getMyShareInfo",
        method: 'POST',
        data: {
            user_id: that.user_id               //user id
        },
        success: function (res) {
            if (res.code == 200) {
                res = JSON.parse(res.data)
                if (res.status == 0) {
                    if (res.data.length > 0) {     //get success
                        that.shareList = res.data
                    } else {                     //get failed
                        prompt.showToast({
                            message: '您还没有分享图书哦'
                        })
                    }
                } else {
                    prompt.showToast({
                        message: '无法连接到服务器，请检查您的网络'
                    })
                }
            } else {
                prompt.showToast({
                    message: '无法连接到服务器，请检查您的网络'
                })
            }
            that.progressShow = false
        },
        fail: function (data, code) {       //internet error
            prompt.showToast({
                message: '无法连接到服务器，请检查您的网络'
            })
            that.progressShow = false
        }
    })
}



/**
 * function:deal with the information of book 
 * parameter:
 *  1.that
 * return:
 **/
function shareManage(that, share_id, flag) {
    fetch.fetch({
        url: that.hostUrl + "user/shareManage",
        method: 'POST',
        data: {
            flag: flag,    //flag=0 删除  flag=1 上架  flag=2 下架
            share_id: share_id,
            user_id: that.user_id
        },
        success: function (res) {
            if (res.code == 200) {
                res = JSON.parse(res.data)
                if (res.status == 0) {
                    if (res.data.result == 0) {
                        if (flag == 2) {
                            prompt.showToast({
                                message: '删除图书成功'
                            })
                        } else if (flag == 1) {
                            prompt.showToast({
                                message: '图书上架成功'
                            })
                        } else {
                            prompt.showToast({
                                message: '图书下架成功'
                            })
                        }
                        getShareInfo(that)
                    } else {
                        prompt.showToast({
                            message: '操作失败,请重试'
                        })
                    }
                } else {
                    prompt.showToast({
                        message: '网络请求失败,请重试'
                    })
                }
            } else {
                prompt.showToast({
                    message: '无法连接到服务器，请检查您的网络'
                })
            }
        }, fail: function (data, code) {
            prompt.showToast({
                message: '无法连接到服务器，请检查您的网络'
            })
        }

    })

}

module.exports = {
    getShareInfo, shareManage
}
