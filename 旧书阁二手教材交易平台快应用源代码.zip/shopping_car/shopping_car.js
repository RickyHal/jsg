import prompt from '@system.prompt'
import router from '@system.router'
import publicFunc from '../public/public.js'
/**
 * function:checked all the books
 * parameter:
 *  1.that
 *return:
 */
function checkedAll(that) {
    that.checked = !that.checked
    var total_price = 0       //total price
    var total_num = 0         //total num
    for (var i = 0; i < that.books.length; i++) {
        if (that.checked == true) {
            that.books[i].checked = true
            total_price = total_price + that.books[i].shoppingCar.price     //add the price of item to total price
            total_num = total_num + that.books[i].shoppingCar.num           //add the num of item to total num
        } else {
            that.books[i].checked = false
            that.total_num = 0
            that.total_price = 0
        }
    }
    that.total_num = total_num
    that.total_price = total_price
    that.total_price = Math.round(that.total_price * 100) / 100
}
/**
 * function:checked one book
 * parameter:
 *  1.that
 *  2.id:book's id
 *return:
 */
function checkItem(that, id) {
    for (var i = 0; i < that.books.length; i++) {
        if (that.books[i].sail_id == id) {
            if (that.books[i].checked == true) {        //cancle book
                that.books[i].checked = false       //item checked flag
                that.checked = false      //total checked flag
                that.total_num = that.total_num - that.books[i].shoppingCar.num
                that.total_price = that.total_price - that.books[i].shoppingCar.price
                that.total_price = Math.round(that.total_price * 100) / 100
            } else {      //select book
                that.books[i].checked = true
                that.total_num = that.total_num + that.books[i].shoppingCar.num
                that.total_price = that.total_price + that.books[i].shoppingCar.price
                that.total_price = Math.round(that.total_price * 100) / 100
            }
        }
    }
}
function toBookInfo(sail_id) {
    router.push({
        uri: '/bookInfo',
        params: { sail_id: sail_id }
    })
}
function toPay(that) {
    var order = {}
    order.total_num = that.total_num
    order.total_price = that.total_price
    order.orderId = publicFunc.getOrderId()
    order.orderTime = publicFunc.getDate() + ' ' + publicFunc.getTime()
    order.sendTime= publicFunc.getDate() + ' ' + publicFunc.getTime()
    var books = []
    for (var i = 0; i < that.books.length; i++) {
        if (that.books[i].checked == true) {
            var book = {}
            book.new = that.books[i].shoppingCar.books[0].new
            book.num = that.books[i].shoppingCar.books[0].num
            book.price =that.books[i].shoppingCar.price *that.books[i].shoppingCar.books[0].num
            book.book_name = that.books[i].book_name
            book.sail_id = that.books[0].sail_id
            books.push(book)
        }
    }
    order.books = books
    if(order.books.length!=0){
        router.push({
            uri: '/pay',
            params: { order: order }
        })
    }else{
        prompt.showToast({
            message: '请先选择教材'
        })
    }
}
module.exports = {
    checkedAll, checkItem, toBookInfo, toPay
}