import fetch from '@system.fetch'
import prompt from '@system.prompt'
function getInfo(that){
    fetch.fetch({
        url: that.hostUrl + "user/getBorrowRec",
        method: 'POST',
        data:{
            share_id:that.share_id
        },
        success: function (res) {
            if (res.code == 200) {
                res = JSON.parse(res.data)
                if (res.status == 0) {
                    if (res.data.length > 0) {     //get success
                        that.userList = res.data
                    } else {                     //get failed
                        prompt.showToast({
                            message: '没有数据'
                        })
                    }
                } else {
                    prompt.showToast({
                        message: '无法连接到服务器，请检查您的网络'
                    })
                }
            } else {
                prompt.showToast({
                    message: '无法连接到服务器，请检查您的网络'
                })
            }
            that.progressShow = false
        },
        fail: function (data, code) {       //internet error
            prompt.showToast({
                message: '无法连接到服务器，请检查您的网络'
            })
            that.progressShow = false
        }
    })
}
module.exports={
    getInfo
}