import fetch from '@system.fetch'
import prompt from '@system.prompt'
function getHot(that){
    fetch.fetch({
        url: that.hostUrl + "user/book/hot",
        method: 'POST',
        success: function (res) {
            if (res.code == 200) {
                 that.hot=JSON.parse(res.data)
            } else {
                prompt.showToast({
                    message: '无法连接到服务器，请检查您的网络'
                })
            }
        },
        fail: function (data, code) {
            prompt.showToast({
                message: '无法连接到服务器，请检查您的网络'
            })
        }
    })
}

module.exports={
    getHot
}