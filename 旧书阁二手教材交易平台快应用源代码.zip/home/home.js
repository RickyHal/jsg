import fetch from '@system.fetch'
import storage from '@system.storage'
import prompt from '@system.prompt'
/**
 * function:search the book
 * parameter:
 *  1.that:parent's this
 *  2.value:the book name of book author or book isbn
 * return:
 */
function search(that, value) {
    that.show.searchShow = true
}
/**
 * function:screen the book 
 * parameter:
 *  1.that:parent's this
 *  2.data:the data screen parameters,include the type and price
 * return:
 */
function screen(that, data) {
    that.show.searchShow = true
}

/**
 * function:get more data of book,number:10
 * parameter:
 *   1.sort:the sort data
 *   2.screen:the screen data
 * return:univercitys list
 */
function getBookInfo(that, flag) {
    if( that.typeId=='全部分类'){
        that.typeId=''
      }
    storage.get({
        key: 'univercity_id',   //get the session key of user log in flag
        success: function (univercity_id) {
            fetch.fetch({
                data: {
                    'key': that.key,
                    'sail': that.sort.sail,
                    'price': that.sort.price,
                    'page': that.screen.page,
                    'price_begin': that.screen.price_begin,
                    'price_end': that.screen.price_end,
                    'typeId': that.typeId,
                    'book_type_id_child':that.book_type_id_child,
                    'universityId': univercity_id,
                },
                method: 'POST',
                url: that.hostUrl + 'user/book/getBooksInfo',
                success: function (res) {
                    if (res.code == 200) {
                        res = JSON.parse(res.data)
                        if (res.status == 0) {
                            // prompt.showToast({
                            //     message: res
                            // })
                            if(flag=='refresh'){
                                prompt.showToast({
                                    message: '刷新成功'
                                })
                            }
                            if (res.data.length < 10) {
                                if (res.data.length == 0) {
                                    if (flag == 'search') {
                                        prompt.showToast({
                                            message: '没有找到相关的教材'
                                        })
                                    }else if(flag=='getMore'){
                                        prompt.showToast({
                                            message: '没有教材了哦'
                                        })
                                    }else{
                                        that.books=[]
                                    }
                                    that.canGetMore = false
                                    that.canRefresh = false
                                    that.screen.page = that.screen.page + 10
                                } else {
                                    that.show.loadShow = false
                                    if (that.books.length >= 10&&flag!='screen') {
                                        for (var i = 0; i < res.data.length; i++) {
                                            that.books.push(res.data[i])
                                        }
                                    } else {
                                        that.books = res.data
                                    }
                                    that.canRefresh = false
                                }
                                that.canRefresh = false
                                that.show.searchShow = false
                                that.show.loadShow = false
                                that.canGetMore = false
                            } else {
                                if (flag == 'getMore') {
                                    for (var i = 0; i < res.data.length; i++) {
                                        that.books.push(res.data[i])
                                    }
                                } else {
                                    that.books = res.data
                                }
                                that.screen.page = that.screen.page + 10
                                that.canRefresh = false
                                that.show.searchShow = false
                                that.show.loadShow = false
                                that.canGetMore = true
                            }
                        } else {
                            prompt.showToast({
                                message: '无法连接到服务器，请检查您的网络'
                            })
                            that.screen.page = 0
                            that.show.canRefresh = false 
                            that.show.searchShow = false
                            that.show.loadShow = false
                        }

                    } else {
                        prompt.showToast({
                            message: '无法连接到服务器，请检查您的网络'
                        })
                        that.screen.page = 0
                        that.show.canRefresh = false
                        that.show.searchShow = false
                        that.show.loadShow = false
                    }
                },
                fail: function (data, code) {
                    prompt.showToast({
                        message: '无法连接到服务器，请检查您的网络'
                    })
                    that.screen.page = 0
                    that.show.canRefresh = false
                    that.show.searchShow = false
                    that.show.loadShow = false
                }
            })
        }
    })
}
export default {
    search, screen, getBookInfo
}
