// 脚本：regenerator.js
// 全局引用
const globalRef = global.__proto__ || global

// global注入regeneratorRuntime
globalRef.regeneratorRuntime = require('babel-runtime/regenerator')