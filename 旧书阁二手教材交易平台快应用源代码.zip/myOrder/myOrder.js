import prompt from '@system.prompt'
/**
 * filename:book_share.js
 * author:Ricky
 * date:2018/10/27
 * marks:
 * 
 */


/**
 * function:delete the order
 * parameter:
 *  1.that
 *  2.id
 * return:
 **/
function deleteOrder(that, orderId) {
    prompt.showContextMenu({
        itemList: ['删除订单'],
        itemColor: '#FFC125',
        success: function (data) {
            if (data.index == 0) {
                var orders = that.orders
                var newOrders = []
                for (var i = 0; i < orders.length; i++) {
                    if (orders[i].orderId != orderId) {
                        newOrders.push(orders[i])
                    }
                }
                that.orders = newOrders
                prompt.showToast({
                    message: '删除成功',
                })
            }
        }
    })
}


/**
 * function:cancel the order
 * parameter:
 *  1.that
 *  2.id
 * return:
 **/
function cancelOrder(that, orderId) {
    prompt.showDialog({
        title: '提示',
        message: '确认取消该订单？',
        buttons: [
            {
                text: '取消',
                color: '#666666'
            }, {
                text: '确定',
                color: '#FFC125'
            },
        ],
        success: function (data) {
            if(data.index==1){
                var orders = that.orders
                var newOrders = []
                for (var i = 0; i < orders.length; i++) {
                    if (orders[i].orderId != orderId) {
                        newOrders.push(orders[i])
                    }
                }
                that.orders = newOrders
                prompt.showToast({
                    message:  '取消成功'
                })
            }
        },
        fail: function (data, code) {
            prompt.showToast({
                message: '取消失败',
            })
        }
    })
}
module.exports = {
    deleteOrder, cancelOrder
}
