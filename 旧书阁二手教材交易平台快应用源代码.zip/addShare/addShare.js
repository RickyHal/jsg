import barcode from '@system.barcode'
import media from '@system.media'
import image from '@system.image'
import prompt from '@system.prompt'
import fetch from '@system.fetch'
import router from '@system.router'
import request from '@system.request'
import publicFunc from '../public/public.js'
/**
 * filename:addShare.js
 * author:Ricky
 * date:2018/10/27
 * marks:
 * 
 */

/**
 * function:scan the ISBN code of book,and set the isbn in parent's data
 * parameter:
 *  1.that
 * return:
 **/
function scan(that) {
    barcode.scan({
        success: function (data) {
            that.shareInfo.book_isbn = data.result
        },
        fail: function (data, code) {
            prompt.showToast({
                message: '扫描失败，请重试'
            })
        },
    })
}
/**
     * function:scan the ISBN code of book,and set the isbn in parent's data
     * parameter:
     *  1.that
     *  2.img:the image url
     * return:
     **/
function chooseImg(that) {
    if (that.shareInfo.book_imgs.length > 2) {
        prompt.showToast({
            message: '最多只能选择3张图片'
        })
    } else {
        prompt.showContextMenu({
            itemList: ['拍照', '从相册选取'],
            itemColor: '#FFC125',
            success: function (data) {
                if (data.index == 0) {
                    media.takePhoto({
                        success: function (data1) {
                            image.compressImage({
                                uri: data1.uri,
                                quality: 80,
                                radio: 2, // 变为原图的1/2大小
                                format: 'JPEG',
                                success: function (data2) {
                                    that.shareInfo.book_imgs.push(data2.uri)
                                },
                                fail: function (data, code) {
                                    prompt.showToast({
                                        message: '压缩图片失败'
                                    })
                                }
                              })
                        }
                    })
                } else {
                    media.pickImage({
                        success: function (data1) {
                            that.shareInfo.book_imgs.push(data1.uri)
                        }
                    })
                }
            }
        })
    }
}
/**
 * function:scan the ISBN code of book,and set the isbn in parent's data
 * parameter:
 *  1.that
 *  2.img:the image url
 * return:
 **/
function deleteImg(that, img) {
    var imgs = that.shareInfo.book_imgs
    var newImgs = []
    for (var i = 0; i < imgs.length; i++) {
        if (imgs[i] != img) {
            newImgs.push(imgs[i])
        }
    }
    that.shareInfo.book_imgs = newImgs
}
var imgNum = 0
var imgs = []
function downLoadImgs(that) {
    if (imgNum < that.shareInfo.book_imgs.length) {
        request.download({
            "url": that.shareInfo.book_imgs[imgNum],
            success: function (data) {
                request.onDownloadComplete({
                    "token": data.token,
                    success: function (data1) {
                        imgs[imgNum] = data1.uri
                        imgNum++;
                        downLoadImgs(that)
                    }, fail: function (data, code) {
                        prompt.showToast({
                            message: '下载图书照片失败'
                        })
                    }
                })
            }, fail: function (data, code) {
                prompt.showToast({
                    message: '下载图书照片失败' + data
                })
            }
        })
    } else {
        that.shareInfo.book_imgs = imgs
    }
}
var count = 0
/**
 * function:up the imgs of book
 * parameter:
 *  1.that
 * return:
 **/
function upImgs(that) {
    if (that.shareInfo.book_name == '' || that.shareInfo.book_name == null) {
        prompt.showToast({
            message: '请输入图书名'
        })
    } else if (that.shareInfo.book_author == '' || that.shareInfo.book_author == null) {
        prompt.showToast({
            message: '请输入图书作者'
        })
    } else if (that.shareInfo.book_isbn == '' || that.shareInfo.book_isbn == null) {
        prompt.showToast({
            message: '请输入图书ISBN号'
        })
    } else if (that.shareInfo.book_isbn.length != 13) {
        prompt.showToast({
            message: 'ISBN号为13位数字'
        })
    } else if (that.shareInfo.canborrowtime_begin == '' || that.shareInfo.canborrowtime_begin == null ||
        that.shareInfo.canborrowtime_end == '' || that.shareInfo.canborrowtime_end == null) {
        prompt.showToast({
            message: '请录入图书可借阅时间'
        })
    } else if (that.shareInfo.book_imgs[count] != null) {
        if (that.shareInfo.book_imgs[count].substring(0, 2) != 'in') {
            prompt.showToast({
                message: '图书照片加载未完成，请稍后'
            })
            that.progressShow = false
        } else {
            if (count < that.shareInfo.book_imgs.length) {
                that.progressShow = true
                prompt.showToast({
                    message: '上传第' + (count + 1) + '张图片中...网速较慢，请稍后',
                    duration:10000
                })
                request.upload({
                    url: that.hostUrl + "user/upShareImgs",
                    method: 'POST',
                    files: [
                        {
                            uri: that.shareInfo.book_imgs[count],
                            name: 'img',
                            filename: 'img.png'
                        }
                    ],
                    success: function (res) {
                        if (res.code == 200) {      //requests  success
                            res = JSON.parse(res.data)
                            if (res.data.src != 1) {   //up success
                                that.shareInfo.book_imgs[count] = res.data.src
                                count++;
                                upImgs(that)
                            } else {
                                prompt.showToast({
                                    message: '上传图片失败'
                                })
                                that.progressShow = false
                            }
                        } else {
                            prompt.showToast({
                                message: '无法连接到服务器，请检查您的网络'
                            })
                            that.progressShow = false
                        }
                    },
                    fail: function (data, code) {       //internet error
                        prompt.showToast({
                            message: '无法连接到服务器'+data+code+'，请检查您的网络'
                        })
                        that.progressShow = false
                    }
                })
            } else {
                addShare(that)
            }
        }
    } else {
        addShare(that)
    }
}
/**
 * function:set the nput value to the sign info in data
 * parameter:
 *   1.type:the input info's number
 *   2.e:include the input info
 *   3.that
 * return:
 */
function setValue(type, e, that) {
    switch (type) {
        case 0:     //input the book name
            that.shareInfo.book_name = e.target.attr.value
            break;
        case 1:     //input the book author
            that.shareInfo.book_author = e.target.attr.value
            break;
        case 2:     //input the isbn
            that.shareInfo.book_isbn = e.target.attr.value
            break;
        case 3:     //input the marks
            that.shareInfo.share_marks = e.target.attr.value
            break;
        default:
    }
}
/**
 * function:add the record of book's share 
 * parameter:
 *   1.that
 * return:
 */
function addShare(that) {
    var imgs = ''
    for (var i = 0; i < that.shareInfo.book_imgs.length; i++) {
        imgs = imgs + that.shareInfo.book_imgs[i] + ' '
    }
    prompt.showToast({
        message: imgs
    })
    fetch.fetch({
        data: {
            "share_id": that.share_id,
            'book_name': that.shareInfo.book_name,
            'book_author': that.shareInfo.book_author,
            'book_isbn': that.shareInfo.book_isbn,
            'imgs': imgs,
            'user_id': that.user_id,
            'canBorrowTime_begin': that.shareInfo.canborrowtime_begin,
            'canBorrowTime_end': that.shareInfo.canborrowtime_end,
            'marks': that.shareInfo.share_marks
        },
        method: 'POST',
        url: that.hostUrl + 'user/amShareBook',
        success: function (res) {
            if (res.code == 200) {
                res = JSON.parse(res.data)
                if (res.status == 0) {
                    if (res.data.type == 0) {
                        if (res.data.result == 0) {
                            prompt.showToast({
                                message: '修改成功'
                            })
                            router.back()
                        } else {
                            prompt.showToast({
                                message: '修改失败'
                            })
                        }
                    } else {
                        if (res.data.result == 0) {
                            prompt.showToast({
                                message: '分享成功'
                            })
                            router.back()
                        } else {
                            prompt.showToast({
                                message: '分享失败'
                            })
                        }
                    }
                } else {
                    prompt.showToast({
                        message: '无法连接到服务器，请检查您的网络'
                    })
                    that.progressShow = false
                }
            } else {
                prompt.showToast({
                    message: '无法连接到服务器，请检查您的网络'
                })
                that.progressShow = false
            }
        },
        fail: function (data, code) {
            prompt.showToast({
                message: '无法连接到服务器，请检查您的网络'
            })
            that.progressShow = false
        }
    })
}
module.exports = {
    scan, chooseImg, deleteImg, setValue, addShare, upImgs, downLoadImgs
}