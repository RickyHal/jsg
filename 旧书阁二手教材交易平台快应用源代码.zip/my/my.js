/**
 * filename:sessionData.js
 * function:
 *  1.chooseLogo:choose the image of logo and upload
 *  2.routerPage:router to the page
 * author:Ricky
 * date:2018/10/31
 * marks:
 * 
 */
import router from '@system.router'
import prompt from '@system.prompt'
import storage from '@system.storage'
import fetch from '@system.fetch'
import media from '@system.media'
import image from '@system.image'
import request from '@system.request'
/**
 * function:choose the image of logo and upload
 * parameter:
 *   1.that
 * return:
 */
function modifyLogo(that) {
  media.pickImage({
    success: function (data) {
      image.editImage({
        uri: data.uri,
        success: function (data1) {
          image.compressImage({
            uri: data1.uri,
            quality: 80,
            radio: 2, // 变为原图的1/2大小
            format: 'JPEG',
            success: function (data2) {
              storage.get({
                key: 'user_id',   //get the session key of user log in flag
                success: function (session_key) {
                  prompt.showToast({
                    message: '上传头像中，请稍后...'
                  })
                  request.upload({
                    url: that.hostUrl + "user/modifyInfo",
                    method: 'POST',
                    files: [
                      {
                        uri: data2.uri,
                        name: 'logo',
                        filename: 'logo.png'
                      }
                    ],
                    data: [
                      {
                        name: 'user_id',
                        value: session_key
                      }
                    ],
                    success: function (res) {
                      if (res.code == 200) {      //requests  success
                        res = JSON.parse(res.data)
                        if (res.data.result == 0) {   //modfied success
                          that.userInfo.user_logo = res.data.url
                          prompt.showToast({
                            message: '修改成功'
                          })
                        } else {
                          prompt.showToast({
                            message: '修改失败'
                          })
                        }
                      } else {
                        prompt.showToast({
                          message: '无法连接到服务器，请检查您的网络'
                        })
                      }
                    },
                    fail: function (data, code) {       //internet error
                      prompt.showToast({
                        message: '无法连接到服务器，请检查您的网络'
                      })
                    }
                  })
                },
                fail: function (data, code) {
                  prompt.showToast({
                    message: '未获取到session'
                  })
                }
              })
            },
            fail: function (data, code) {
              console.log(`handling fail, code = ${code}`)
            }
          })
        }
      })
    }
  })
}
/**
 * function:router to the page
 * parameter:
 *   1.that:
 *   2.url:page's url
 *   3.data:the data send to page
 * return:
 */
function routerPage(that, url, data) {
  if (data == '退出') {   //log out
    storage.get({
      key: 'user_id',   //get the session key of user log in flag
      success: function (session_key) {
        logOut(that, session_key, url)    //log out
      },
      fail: function (data, code) {
        prompt.showToast({
          message: '未获取到session'
        })
      }
    })
  } else {
    router.push({
      uri: url,
      params: { title: '修改密码', univercity_name: that.userInfo.univercity, user_id: that.userInfo.user_id }
    });
  }
}
/**
 * function:log out
 * parameter:
 *   1.that:
 *   2.session_key:the  session key of user log in flag
 *   3.url:page's url
 * return:
 */
function logOut(that, session_key, url) {
  fetch.fetch({
    url: that.hostUrl + "user/logOut",
    method: 'POST',
    data: {
      session_key: session_key
    },
    success: function (res) {
      if (res.code == 200) {    //if request success
        res = JSON.parse(res.data)
        if (res.data.result == 0) {   //if log out success
          router.replace({
            uri: url,
          });
        } else {      //log out failed
          prompt.showToast({
            message: '退出失败'
          })
        }
      } else {
        prompt.showToast({
          message: '无法连接到服务器，请检查您的网络'
        })
      }
    },
    fail: function (data, code) {       //internet error
      prompt.showToast({
        message: '无法连接到服务器，请检查您的网络'
      })
    }
  })
}
module.exports = {
  modifyLogo, routerPage
}