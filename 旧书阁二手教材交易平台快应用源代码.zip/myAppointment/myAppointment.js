import prompt from '@system.prompt'
import fetch from '@system.fetch'

/**
 * filename:book_share.js
 * author:Ricky
 * date:2018/10/27
 * marks:
 * 
 */


/**
 * function:cancel sales transaction 
 * parameter:
 *  1.that
 *  2.id
 * return:
 **/
function cancelAppointment(that, id) {
  prompt.showDialog({
    title: '提示',
    message: '确认取消该预约？',
    buttons: [
      {
        text: '取消',
        color: '#666666'
      }, {
        text: '确定',
        color: '#FFC125'
      },
    ],
    success: function (data) {
      if (data.index == 1) {
        fetch.fetch({
          url: that.hostUrl + "user/cancelAppointment",
          method: 'POST',
          data: {
            appointment_id: id               //appointment id
          },
          success: function (res) {
            if (res.code == 200) {
              res = JSON.parse(res.data)
              if (res.status == 0) {
                if (res.data.result == 0) {     //get appointments success
                  prompt.showToast({
                    message: '取消成功'
                  })
                  getAppointments(that)
                } else {                  //get appointments failed
                  prompt.showToast({
                    message: '取消失败，请稍后重试'
                  })
                }
              } else {
                prompt.showToast({
                  message: '无法连接到服务器，请检查您的网络'
                })
              }
            } else {
              prompt.showToast({
                message: '无法连接到服务器，请检查您的网络'
              })
            }
          },
          fail: function (data, code) {       //internet error
            prompt.showToast({
              message: '无法连接到服务器，请检查您的网络'
            })
          }
        })
      }
    },
    fail: function (data, code) {
      prompt.showToast({
        message: '取消失败，请稍后重试'
      })
    }
  })
}



/**
 * function:check dating information
 * parameter:
 *  1.that
 * return:
 **/
function getAppointments(that) {
  fetch.fetch({
    url: that.hostUrl + "user/getAppointments",
    method: 'POST',
    data: {
      user_id: that.user_id,               //user id
    },
    success: function (res) {
      if (res.code == 200) {
        res = JSON.parse(res.data)
        if (res.status == 0) {
          if (res.data.length != 0) {     //get appointments success
            that.appointments = res.data
          } else {                  //get appointments failed
            prompt.showToast({
              message: '您还没有预约哦'
            })
            that.appointments = []
          }
        } else {
          prompt.showToast({
            message: '无法连接到服务器，请检查您的网络'
          })
        }
      } else {
        prompt.showToast({
          message: '无法连接到服务器，请检查您的网络'
        })
      }
      that.progressShow = false
    },
    fail: function (data, code) {       //internet error
      prompt.showToast({
        message: '无法连接到服务器，请检查您的网络'
      })
    }
  })
}
module.exports = {
  cancelAppointment, getAppointments
}