import prompt from '@system.prompt'
import fetch from '@system.fetch'
import router from '@system.router'

/**
 * filename:book_share.js
 * author:Ricky
 * date:2018/10/27
 * marks:
 * 
 */

/**
 * function:get the list of shared book
 * parameter:
 *  1.that
 * return:
 **/
function getShareList(that) {
    fetch.fetch({
        url: that.hostUrl + "user/getShareList",
        method: 'POST',
        data: {
            key: that.key,
            page: that.page
        },
        success: function (res) {
            if (res.code == 200) {
                res = JSON.parse(res.data)
                if (res.status == 0) {
                    if (res.data.length != 0) {
                        that.shareList = res.data
                        that.page = that.page + 10
                    } else {
                        prompt.showToast({
                            message: '没有找到分享的图书哦'
                        })
                        that.page = 0
                    }
                } else {
                    prompt.showToast({
                        message: '网络请求失败,请重试'
                    })
                    that.page = 0
                }
            } else {
                prompt.showToast({
                    message: '无法连接到服务器，请检查您的网络'
                })
                that.page = 0
            }
            that.canRefresh = false
            that.show.loadShow = false
            that.show.progressShow = false
        }, fail: function (data, code) {
            prompt.showToast({
                message: '无法连接到服务器，请检查您的网络'
            })
            that.page = 0
            that.show.loadShow = false
        }
    })
}
module.exports = {
    getShareList
}