/**
 * filename:signUp.js
 * function:
 *  1.setValue: set the user input infomation 
 *  2.modifiedPasswd:modify the user's password
 * author:Ricky
 * date:2018/10/27
 * marks:
 * 
 */
import publicFunc from '../public/public.js'
import router from '@system.router'
import prompt from '@system.prompt'
import fetch from '@system.fetch'
/**
 * function:set the nput value to the sign info in data
 * parameter:
 *   1.type:the input info's number
 *   2.e:include the input info
 *   3.that
 * return:
 */
function setValue(type, e, that) {
    switch (type) {
        case 0:     //input the email
            that.email = e.target.attr.value
            break;
        case 1:     //input the eamil check code
            that.code = e.target.attr.value
            break;
        case 2:     //input the password 
            that.newPasswd = e.target.attr.value
            break;
        case 3:     //input the check password
            that.checkPasswd = e.target.attr.value
            break;
        default:
    }
}
/**
 * function:modify the user's password
 * parameter:
 *   1.that
 * return:
 */
function modifiedPasswd(that) {
    if (that.code == '') {     //if the email check code isn's input
        prompt.showToast({
            message: '请输入验证码'
        })
    } else if (that.code.length < 6) {  //if the email check code's length<6
        prompt.showToast({
            message: '验证码为6位'
        })
    } else if (publicFunc.checkPasswd(that.newPasswd, that.checkPasswd)) {
        fetch.fetch({
            url: that.hostUrl + "user/modifyPasswd",
            data: {
                email: that.email,
                code: that.code,
                newPasswd: that.newPasswd,
                session_key: that.session_key
            },
            method: 'POST',
            success: function (res) {
                if (res.code == 200) {
                    res = JSON.parse(res.data)
                    if (res.status == 0) {
                        if (res.data.result == 0) {
                            prompt.showToast({
                                message: '修改成功'
                            })
                            router.back()
                        } else if (res.data.hasSignUp == 1) {
                            prompt.showToast({
                                message: '用户不存在'
                            })
                        } else if (res.data.codeCheck == 1) {
                            prompt.showToast({
                                message: '验证码不正确'
                            })
                        }
                        else {
                            prompt.showToast({
                                message: '修改失败，请稍后重试'
                            })
                        }
                    } else {
                        prompt.showToast({
                            message: '请求方式错误'
                        })
                    }
                } else {
                    prompt.showToast({
                        message: '无法连接到服务器，请检查您的网络'
                    })
                }
            },
            fail: function (data, code) {
                prompt.showToast({
                    message: '无法连接到服务器，请检查您的网络'
                })
            }
        })
    }
}
function getEmailCode(that) {
    if (publicFunc.checkEmail(that.email)) {
        publicFunc.getEmailCode(that, that.email, 1)
    }
}
module.exports = {
    setValue, modifiedPasswd, getEmailCode
}