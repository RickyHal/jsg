import prompt from '@system.prompt'
import fetch from '@system.fetch'
import router from '@system.router'
import storage from '@system.storage'
function getShareInfo_Detail(that) {
    storage.get({
        key: 'user_id',   //get the session key of search history
        success: function (user_id) {
            fetch.fetch({
                url: that.hostUrl + "user/getShareBookDetail",
                method: 'POST',
                data: {
                    share_id: that.share_id,
                    book_isbn: that.book_isbn,
                    user_id: user_id
                },
                success: function (res) {
                    if (res.code == 200) {
                        res = JSON.parse(res.data)
                        if (res.status == 0) {
                            if (res.data != '') {
                                if(res.data.hasBorrow==1){
                                    that.contactShow = true
                                }
                                that.bookInfo_detail = res.data
                            } else {
                                prompt.showToast({
                                    message: '没有这本书的分享记录哦'
                                })
                                router.back()
                            }
                        } else {
                            prompt.showToast({
                                message: '请求失败,请稍后重试'
                            })
                        }
                    } else {
                        prompt.showToast({
                            message: '无法连接到服务器，请检查您的网络'
                        })
                    }
                    that.progressShow = false
                }, fail: function (data, code) {
                    prompt.showToast({
                        message: '无法连接到服务器，请检查您的网络'
                    })
                    that.progressShow = false
                }
            })
        }, fail: function (data, code) {
            prompt.showToast({
                message: '无法连接到服务器，请检查您的网络'
            })
        }
    })
}
function borrow(that) {
    storage.get({
        key: 'user_id',   //get the session key of search history
        success: function (user_id) {
            fetch.fetch({
                url: that.hostUrl + "user/borrowShareBook",
                method: 'POST',
                data: {
                    share_id: that.share_id,
                    user_id: user_id
                },
                success: function (res) {
                    if (res.code == 200) {
                        res = JSON.parse(res.data)
                        if (res.status == 0) {
                            that.contactShow = true
                            prompt.showToast({
                                message: '借阅成功，请联系该书的主人借书'
                            })
                        } else {
                            prompt.showToast({
                                message: '借阅失败'
                            })
                        }
                    } else {
                        prompt.showToast({
                            message: '无法连接到服务器，请检查您的网络'
                        })
                    }
                }, fail: function (data, code) {
                    prompt.showToast({
                        message: '无法连接到服务器，请检查您的网络'
                    })
                }
            })
        }
    })
}
module.exports = {
    getShareInfo_Detail, borrow
}