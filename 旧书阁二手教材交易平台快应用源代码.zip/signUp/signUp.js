/**
 * filename:signUp.js
 * function:
 *  1.signUp:sign up
 *  2.getEmailCode:get the email check code
 *  3.setValue: set the user input infomation 
 * author:Ricky
 * date:2018/10/27
 * marks:
 * 
 */
import prompt from '@system.prompt'
import fetch from '@system.fetch'
import router from '@system.router'
import publicFunc from '../public/public.js'
/**
 * function:sign up
 * parameter:
 *   1.that
 * return:
 */
function signUp(that) {
    if (that.signInfo.username == '') {
        prompt.showToast({
            message: '请输入用户名'
        })
    } else {
        //check the input data
        if (publicFunc.checkPasswd(that.signInfo.passwd, that.signInfo.passwd1) && publicFunc.checkName(that.signInfo.name)
            && publicFunc.checkTel(that.signInfo.tel) && publicFunc.checkQQ(that.signInfo.qq) && publicFunc.checkEmail(that.signInfo.email)) {
            if (that.signInfo.code == '') {     //if the email check code isn's input
                prompt.showToast({
                    message: '请输入验证码'
                })
            } else if (that.signInfo.code.length < 6) {  //if the email check code's length<6
                prompt.showToast({
                    message: '验证码为6位'
                })
            } else {  //sign up
                fetch.fetch({
                    url: that.hostUrl + "user/signUp",
                    method: 'POST',
                    data: {
                        univercityId: that.signInfo.univercityId,       //user's unnivercity id
                        username: that.signInfo.username,               //user's username
                        name: that.signInfo.name,                       //user's name   
                        passwd: that.signInfo.passwd,                   //user's password
                        tel: that.signInfo.tel,                         //user's telephone
                        qq: that.signInfo.qq,                           //user's qq
                        email: that.signInfo.email,                     //user's email
                        code: that.signInfo.code,                       //user's email check code
                        session_key: that.session_key                    //the session key of email check code in server
                    },
                    success: function (res) {
                        if (res.code == 200) {
                            res = JSON.parse(res.data)
                            if (res.data.result == 0) {
                                prompt.showToast({
                                    message: '注册成功'
                                })
                                router.push({       //sign up success,router to the login page,send the data:1.username,2.password
                                    uri: '/logIn',
                                    params: { username: that.signInfo.username, passwd: that.signInfo.passwd }
                                })
                            } else if (res.data.result == 1) {
                                prompt.showToast({
                                    message: '注册失败'
                                })
                            }
                            else if (res.data.result == 2) {                //sign up failed，code is error
                                prompt.showToast({
                                    message: '验证码错误'
                                })
                            } else if (res.data.result == 3) {       //user has exist
                                prompt.showToast({
                                    message: '用户已存在'
                                })
                            }
                        } else {
                            prompt.showToast({
                                message: '无法连接到服务器，请检查您的网络'
                            })
                        }
                    },
                    fail: function (data, code) {       //internet error
                        prompt.showToast({
                            message: '无法连接到服务器，请检查您的网络'
                        })
                    }
                })
            }
        }
    }
}
/**
 * function:get the email check code
 * parameter:
 *   1.that
 * return:
 */
function getEmailCode(that) {
    if (that.signInfo.username == '') { //if the username isn's input
        prompt.showToast({
            message: '请输入用户名'
        })
    }
    //check the input data
    else if (publicFunc.checkPasswd(that.signInfo.passwd, that.signInfo.passwd1) && publicFunc.checkName(that.signInfo.name)
        && publicFunc.checkTel(that.signInfo.tel) && publicFunc.checkQQ(that.signInfo.qq) && publicFunc.checkEmail(that.signInfo.email)) {
        //get the email check code from server
        publicFunc.getEmailCode(that, that.signInfo.email, 0)
    }
}
/**
 * function:set the nput value to the sign info in data
 * parameter:
 *   1.type:the input info's number
 *   2.e:include the input info
 *   3.that
 * return:
 */
function setValue(type, e, that) {
    switch (type) {
        case 0:     //input the username
            that.signInfo.username = e.target.attr.value
            break;
        case 1:     //input the password
            that.signInfo.passwd = e.target.attr.value
            break;
        case 2:     //input the password again
            that.signInfo.passwd1 = e.target.attr.value
            break;
        case 3:     //input the user's name
            that.signInfo.name = e.target.attr.value
            break;
        case 4:     //input the user's telephone number
            that.signInfo.tel = e.target.attr.value
            break;
        case 5:     //input the user's qq
            that.signInfo.qq = e.target.attr.value
            break;
        case 6:     //input the user's email
            that.signInfo.email = e.target.attr.value
            break;
        case 7:     //input the email check code
            that.signInfo.code = e.target.attr.value
            break;
        default:
    }
}
module.exports = {
    signUp, getEmailCode, setValue
}