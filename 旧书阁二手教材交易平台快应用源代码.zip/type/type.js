import fetch from '@system.fetch'
import storage from '@system.storage'
import prompt from '@system.prompt'


/**
 * filename:book_share.js
 * author:Ricky
 * date:2018/10/27
 * marks:
 * 
 */

/**
 * function:get the types of marketing book
 * parameter:
 *  1.that
 * return:
 **/
function getTypes(that,flag) {
    fetch.fetch({
        method: 'POST',
        url: that.hostUrl + 'user/book/getTypes',
        success: function (res) {
            if (res.code == 200) {
                res = JSON.parse(res.data)
                if (res.status == 0) {
                    if(flag==1){
                        that.types = res.data.slice(1)
                        that.typeId = that.types[0].book_type_id
                    }else{
                        that.types = res.data
                    }
                } else {
                    prompt.showToast({
                        message: '没有分类信息'
                    })
                }
            } else {
                prompt.showToast({
                    message: '无法连接到服务器，请检查您的网络'
                })
            }
        },
        fail: function (data, code) {
            prompt.showToast({
                message: '无法连接到服务器，请检查您的网络'
            })
        }
    })
}


/**
 * function:get the information of marketing book
 * parameter:
 *  1.that
 *  2.flag
 * return:
 **/
function getBookInfo(that, flag) {
    that.bookShow=false
        storage.get({
        key: 'univercity_id',   //get the session key of user log in flag
        success: function (univercity_id) {
            fetch.fetch({
                data: {
                    'typeId': that.typeId,
                    'universityId': univercity_id
                },
                method: 'POST',
                url: that.hostUrl + 'user/book/getBookCover',
                success: function (res) {
                    if (res.code == 200) {
                        res = JSON.parse(res.data)
                        if (res.status == 0) {
                            if (res.data.length == 0) {
                                prompt.showToast({
                                    message: '没有图书了哦'
                                })
                                that.progressShow = false
                            } else {
                                if (flag == 'getMore') {
                                    for (var i = 0; i < res.data.length; i++) {
                                        that.books.push(res.data[i])
                                    }
                                } else {
                                    that.books = res.data
                                }
                                that.progressShow = false
                                that.page = that.page + 10
                                that.bookShow=true
                            }
                        } else {
                            prompt.showToast({
                                message: '无法连接到服务器，请检查您的网络'
                            })
                        }
                    } else {
                        prompt.showToast({
                            message: '无法连接到服务器，请检查您的网络'
                        })
                    }
                },
                fail: function (data, code) {
                    prompt.showToast({
                        message: '无法连接到服务器，请检查您的网络'
                    })
                }
            })
        }
    })
}
module.exports = {
    getTypes, getBookInfo
}
