import fetch from '@system.fetch'
import router from '@system.router'
import prompt from '@system.prompt'
import publicFunc from '../public/public.js'
function appoint(that) {
    if (publicFunc.checkName(that.apppointing.contact) && publicFunc.checkTel(that.apppointing.tel) &&
        publicFunc.checkQQ(that.apppointing.qq)) {
        if (that.apppointing.book_num == null || that.apppointing.book_num == '' || that.apppointing.book_num == 0) {
            prompt.showToast({
                message: '请输入教材数量'
            })
        } else if (that.apppointing.upDoorDate == '' || that.apppointing.upDoorTime == '') {
            prompt.showToast({
                message: '请选择时间'
            })
        } else if (that.apppointing.adress == '' || that.apppointing.adress == null) {
            prompt.showToast({
                message: '请输入您的地址，以便于我们为您服务'
            })
        }
        else {
            fetch.fetch({
                url: that.hostUrl + "user/appoint",
                method: 'POST',
                data: {
                    user_id: that.apppointing.user_id,               //user id
                    book_num: that.apppointing.book_num,              //book number
                    book_cell: that.apppointing.book_cell,              //book number's cell
                    upDoorDate: that.apppointing.upDoorDate,             //up door date
                    upDoorTime: that.apppointing.upDoorTime,              //up door time
                    contact: that.apppointing.contact,                    //contact name
                    tel: that.apppointing.tel,                           //telphone
                    qq: that.apppointing.qq,                             //qq
                    adress: that.apppointing.adress                      //up door adress
                },
                success: function (res) {
                    if (res.code == 200) {
                        res = JSON.parse(res.data)
                        if (res.status == 0) {
                            if (res.data.result == 0) {     //appoint success
                                prompt.showToast({
                                    message: '预约成功，请等待客服人员主动联系您'
                                })
                                router.back()
                            } else {                  //appoint failed
                                prompt.showToast({
                                    message: '预约失败，请稍后重试'
                                })
                            }
                        } else {
                            prompt.showToast({
                                message: '无法连接到服务器，请检查您的网络'
                            })
                        }
                    } else {
                        prompt.showToast({
                            message: '无法连接到服务器，请检查您的网络'
                        })
                    }
                },
                fail: function (data, code) {       //internet error
                    prompt.showToast({
                        message: '无法连接到服务器，请检查您的网络'
                    })
                }
            })
        }
    }
}
/**
 * function:set the nput value to the sign info in data
 * parameter:
 *   1.type:the input info's number
 *   2.e:include the input info
 *   3.that
 * return:
 */
function setValue(type, e, that) {
    switch (type) {
        case 0:     //input the book number
            that.apppointing.book_num = e.target.attr.value
            break;
        case 1:     //input the contact
            that.apppointing.contact = e.target.attr.value
            break;
        case 2:     //input the tel
            that.apppointing.tel = e.target.attr.value
            break;
        case 3:     //input the qq
            that.apppointing.qq = e.target.attr.value
            break;
        case 4:     //input the adress
            that.apppointing.adress = e.target.attr.value
            break;
        default:
    }
}
module.exports = {
    appoint, setValue
}