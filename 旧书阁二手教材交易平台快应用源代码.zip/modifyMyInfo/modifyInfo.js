/**
 * filename:signUp.js
 * function:
 *  1.modify:modify user info
 *  2.getEmailCode:get the email check code
 *  3.setValue: set the user input infomation 
 * author:Ricky
 * date:2018/11/11
 * marks:
 * 
 */
import prompt from '@system.prompt'
import fetch from '@system.fetch'
import router from '@system.router'
import publicFunc from '../public/public.js'
/**
 * function:modify user infomation
 * parameter:
 *   1.that
 * return:
 */
function modify(that) {
    //check the input data
    if (publicFunc.checkName(that.userInfo.name) && publicFunc.checkTel(that.userInfo.tel)
        && publicFunc.checkQQ(that.userInfo.qq)) {
        if (that.userInfo.code == '') {     //if the email check code isn's input
            prompt.showToast({
                message: '请输入验证码'
            })
        } else if (that.userInfo.code.length < 6) {  //if the email check code's length<6
            prompt.showToast({
                message: '验证码为6位'
            })
        } else {  //modify
            fetch.fetch({
                url: that.hostUrl + "user/modifyInfo",
                method: 'POST',
                data: {
                    user_id: that.userInfo.user_id,                     //user's id
                    univercity_id: that.userInfo.univercity_id,       //user's unnivercity id
                    user_tel: that.userInfo.tel,                         //user's telephone
                    user_qq: that.userInfo.qq,                           //user's qq
                    user_adress: that.userInfo.user_adress,          //user's adress
                    code: that.userInfo.code,                       //user's email check code
                    session_key: that.session_key                    //the session key of email check code in server
                },
                success: function (res) {
                    if (res.code == 200) {
                        res = JSON.parse(res.data)
                        if (res.data.result == 0) {
                            prompt.showToast({
                                message: '修改成功'
                            })
                            router.back()
                        } else if (res.data.result == 1) {
                            prompt.showToast({
                                message: '验证码错误'
                            })
                        } else if (res.data.result == 2) {
                            prompt.showToast({
                                message: '请登录'
                            })
                            router.replace({
                                uri: '/logIn'
                            })
                        } else {
                            prompt.showToast({
                                message: '修改失败'
                            })
                        }
                    } else {
                        prompt.showToast({
                            message: '无法连接到服务器，请检查您的网络'
                        })
                    }
                },
                fail: function (data, code) {       //internet error
                    prompt.showToast({
                        message: '无法连接到服务器，请检查您的网络'
                    })
                }
            })
        }
    }
}
/**
 * function:get the email check code
 * parameter:
 *   1.that
 * return:
 */
function getEmailCode(that) {
    //check the input data
    if (publicFunc.checkTel(that.userInfo.tel) && publicFunc.checkQQ(that.userInfo.qq)
        && publicFunc.checkEmail(that.userInfo.email)) {
        //get the email check code from server
        publicFunc.getEmailCode(that, that.userInfo.email, 0)
    }
}
/**
 * function:set the nput value to the sign info in data
 * parameter:
 *   1.type:the input info's number
 *   2.e:include the input info
 *   3.that
 * return:
 */
function setValue(type, e, that) {
    switch (type) {
        case 0:     //input the user'sname
            that.userInfo.name = e.target.attr.value
            break;
        case 1:     //input the telephone number
            that.userInfo.tel = e.target.attr.value
            break;
        case 2:     //input the user's qq
            that.userInfo.qq = e.target.attr.value
            break;
        case 3:     //input the user's adress
            that.userInfo.user_adress = e.target.attr.value
            break;
        case 4:     //input the email check code
            that.userInfo.code = e.target.attr.value
            break;
        default:
    }
}
module.exports = {
    modify, getEmailCode, setValue
}