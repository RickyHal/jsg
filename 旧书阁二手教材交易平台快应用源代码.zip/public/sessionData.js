/**
 * filename:sessionData.js
 * function:
 *  1.storeData:store the session data store in local
 *  2.getData:get the session data store in local
 *  3.clearData: clear all the session data store in local
 *  4.deleteData:delete the session data store in local
 * author:Ricky
 * date:2018/10/27
 * marks:
 * 
 */
import storage from '@system.storage'
import prompt from '@system.prompt'
import { resolve } from 'path';
const globalRef = global.__proto__ || global
globalRef.regeneratorRuntime = require('babel-runtime/regenerator')
/**
 * function:store the session data store in local
 * parameter:
 *   1.key:the data's key
 *   2.value:the data
 * return:
 */
function storeData(key, value) {
    storage.set({
        key: key,
        value: value,
        success: function (data) {
        },
        fail: function (data, code) {
            prompt.showToast({
                message: '未存储session'
            })
        }
    })
}
/**
 * function:get the session data store in local
 * parameter:
 *   1.key：the data's key
 * return:
 */
function getData(key) {
    return new Promise(function (resolve) {
        storage.get({
            key: key,
            success: function (data) {
                resolve(data)
            },
            fail: function (data, code) {
                prompt.showToast({
                    message: '未获取到session'
                })
                resolve(null)
            }
        })
    })
}
/**
 * function:clear all the session data store in local
 * parameter:
 * return:
 */
function clearData() {
    storage.clear({
        success: function (data) {
        },
        fail: function (data, code) {
            prompt.showToast({
                message: '清除失败'
            })
        }
    })
}
/**
 * function:delete the session data store in local
 * parameter:
 *  1.key:the data's key
 * return:
 */
function deleteData(key) {
    storage.delete({
        key: key,
        success: function (data) {

        },
        fail: function (data, code) {
            prompt.showToast({
                message: '清除失败'
            })
        }
    })
}
module.exports = {
    storeData, getData, clearData, deleteData
}