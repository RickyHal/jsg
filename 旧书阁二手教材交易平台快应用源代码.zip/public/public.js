import barcode from '@system.barcode'
import clipboard from '@system.clipboard'
import router from '@system.router'
import prompt from '@system.prompt'
import Image from '@system.image'
import request from '@system.request'
import media from '@system.media'
import record from '@system.record'
import fetch from '@system.fetch'
import storage from '@system.storage'
import audio from '@system.audio'
import session from '../public/sessionData.js'
/**
 * function:scan the ISBN code of book,and set the isbn in parent's data
 * parameter:
 *  1.that
 * return:
 **/
function scan(that) {
    barcode.scan({
        success: function (data) {
            if (that.page == 'book_share') {
                router.push({
                    uri: '/share_book_info',
                    params: { book_isbn: data.result }
                })
            } else {
                router.push({
                    uri: '/bookInfo',
                    params: { book_isbn: data.result }
                })
            }
        },
        fail: function (data, code) {
            prompt.showToast({
                message: '扫描失败，请重试'
            })
        }
    })
}
/**
 * function:copy the text
 * parameter:
 *  1.text:the text want to copy
 * return:
 **/
function copyText(text) {
    clipboard.set({
        text: text
    })
    prompt.showToast({
        message: '复制成功',
    })
}
/**
* function:save the img by internet  url
* parameter: 
*   1.img:the image internet url
* return:
**/
function saveImg(img) {
    request.download({
        "url": img,
        success: function (data) {
            request.onDownloadComplete({
                "token": data.token,
                success: function (data) {
                    var src = data.uri
                    prompt.showContextMenu({
                        itemList: ['保存到本地'],
                        itemColor: '#FFC125',
                        success: function (data) {
                            if (data.index == 0) {
                                media.saveToPhotosAlbum({
                                    uri: src,
                                    success: function (data) {
                                        prompt.showToast({
                                            message: '保存成功',
                                        })
                                    }, fail: function (code) {
                                        prompt.showToast({
                                            message: '保存失败',
                                        })
                                    }
                                })
                            }
                        }
                    })
                },
                fail: function (data, code) {
                    prompt.showToast({
                        message: '保存失败'
                    })
                }
            })
        },
        fail: function (data, code) {
            prompt.showToast({
                message: '保存失败'
            })
        }
    })
}
/**
* function:get now date
* parameter: 
* return:date:YYYY-MM-DD
**/
function getDate() {
    var date = new Date();
    var seperator1 = "-";
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = year + seperator1 + month + seperator1 + strDate;
    return currentdate;
}
/**
* function:get now time
* parameter: 
* return:date:HH MM SS
**/
function getTime() {
    var date = new Date();
    var seperator1 = ":";
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var seconds = date.getSeconds();
    if (minutes >= 0 && minutes < 10) {
        minutes = '0' + minutes
    }
    if (seconds >= 0 && seconds < 10) {
        seconds = '0' + seconds
    }
    var currenTime = hours + seperator1 + minutes + seperator1 + seconds;
    return currenTime;
}
/**
 * function:get the univercity list
 * parameter:
 *  1.that
 * return:univercitys list
 */
function getUnivercitys(that) {
    fetch.fetch({
        url: that.hostUrl + "user/getUnivercitys",
        method: 'POST',
        success: function (res) {
            if (res.code == 200) {
                res = JSON.parse(res.data)
                if (res.status == 0) {
                    that.univercitys = res.data
                    session.storeData('univercitys', res.data)
                } else {
                    prompt.showToast({
                        message: '获取高校信息失败'
                    })
                }
            } else {
                prompt.showToast({
                    message: '无法连接到服务器，请检查您的网络'
                })
            }
        },
        fail: function (data, code) {
            prompt.showToast({
                message: '无法连接到服务器，请检查您的网络'
            })
        }
    })
}
/**
* function:check the user has login or has signUp
* parameter: 
* return:
**/
function checkUser() {

}
/**
* function:get email check code
* parameter: 
*  1.that
*  2.email:the email
*  3.type:do what things,0:sign up, 1:modify password
* return:
**/
function getEmailCode(that, email, type) {
    var time = 29
    fetch.fetch({
        url: that.hostUrl + "user/getEmailCode",
        data: {
            email: email
        },
        method: 'POST',
        success: function (res) {
            if (res.code == 200) {
                res = JSON.parse(res.data)
                if (type == 0) { //sign up
                    if (res.status == 0) {
                        prompt.showToast({
                            message: '发送成功，如未收到邮件请检查您的垃圾箱'
                        })
                        that.session_key = res.session_key
                    } else {
                        prompt.showToast({
                            message: '发送失败，请稍后重试'
                        })
                    }
                } else if (type == 1) {  //modify password
                    if (res.data.hasSignUp == 0) {
                        if (res.status == 0) {
                            prompt.showToast({
                                message: '发送成功，如未收到邮件请检查您的垃圾箱'
                            })
                            that.session_key = res.session_key
                        } else {
                            prompt.showToast({
                                message: '发送失败，请稍后重试'
                            })
                        }
                    } else {
                        prompt.showToast({
                            message: '用户不存在'
                        })
                    }
                }
            } else {
                prompt.showToast({
                    message: '无法连接到服务器，请检查您的网络'
                })
            }
        },
        fail: function (data, code) {
            prompt.showToast({
                message: '无法连接到服务器，请检查您的网络'
            })
        }
    })
    time = setTime(that, time)
    var timer
    timer = setInterval(function () {
        time = setTime(that, time, timer)
    }, 1000)
}
/**
* function:set the button's style of get the email code
* parameter: 
*  1.that
*  2.time:the time showed in the button
* return:
*  1.time:the time showed in the button
**/
function setTime(that, time, timer) {
    if (time > 0) {
        that.btnInfo.disable = true
        that.btnInfo.bg_color = '#EDEDED'
        that.btnInfo.color = '#FFC125'
        that.btnInfo.text = time + 's'
        time--;
    } else {
        time = 29
        clearInterval(timer)
        that.btnInfo.disable = false
        that.btnInfo.bg_color = '#FFC125'
        that.btnInfo.color = '#FFFFFF'
        that.btnInfo.text = '获取验证码'
    }
    return time
}
/**
* function:check the name whether is Chinese
* parameter: 
*  1.name:the name
* return:
*  1.boolean
**/
function checkName(name) {
    var p = /^[\u4E00-\u9FA5\uf900-\ufa2d·s]{2,20}$/;
    if (name == '' || name == null) {
        prompt.showToast({
            message: '请输入姓名'
        })
        return false
    } else if (!p.test(name)) {
        prompt.showToast({
            message: '姓名格式不正确'
        })
        return false
    } else {
        return true
    }
}
/**
* function:check the telephone number
* parameter: 
*  1.tel:the the telephone number
* return:
*  1.boolean
**/
function checkTel(tel) {
    var p = /^0?1[3|4|5|7|8][0-9]\d{8}$/;
    if (tel == '' || tel == null) {
        prompt.showToast({
            message: '请输入电话'
        })
        return false
    } else if (!(p.test(tel))) {
        prompt.showToast({
            message: '电话格式不正确'
        })
        return false
    } else {
        return true
    }
}
/**
* function:check the password
* parameter: 
*  1.passwd:the password
*  2.passwd1:the check password
* return:
*  1.boolean
**/
function checkPasswd(passwd, passwd1) {
    var p = /[A-Za-z].*[0-9]|[0-9].*[A-Za-z]/
    if (passwd == '' || passwd1 == '' || passwd == null || passwd1 == null) {
        prompt.showToast({
            message: '请输入密码'
        })
        return false
    }
    else if (passwd != passwd1) {
        prompt.showToast({
            message: '两次输入的密码不一致'
        })
        return false
    } else if (passwd.length > 16 || passwd.length < 6) {
        prompt.showToast({
            message: '密码为6-16位'
        })
        return false
    } else if (!(p.test(passwd))) {
        prompt.showToast({
            message: '密码必须包含字母和数字'
        })
        return false
    } else {
        return true
    }
}
/**
* function:check the qq
* parameter: 
*  1.qq:the qq
* return:
*  1.boolean
**/
function checkQQ(qq) {
    if (isNaN(qq) && qq != '' && qq != null) {
        prompt.showToast({
            message: 'qq格式不对'
        })
        return false
    } else {
        return true
    }
}
/**
* function:check the email
* parameter: 
*  1.email:the email
* return:
*  1.boolean
**/
function checkEmail(email) {
    var p = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    if (email == '' || email == null) {
        prompt.showToast({
            message: '请输入邮箱'
        })
        return false
    } if (!(p.test(email))) {
        prompt.showToast({
            message: '邮箱格式不正确'
        })
        return false
    } else {
        return true
    }
}
/**
* function:get user's info
* parameter: 
* return:
**/
function getUsernfo(that) {
    storage.get({
        key: 'user_id',   //get the session key of user log in flag
        success: function (session_key) {
            fetch.fetch({
                data: {
                    'user_id': session_key
                },
                method: 'POST',
                url: that.hostUrl + 'user/getUserInfo',
                success: function (res) {
                    if (res.code == 200) {
                        res = JSON.parse(res.data)
                        if (res.status == 0) {
                            that.userInfo = res.data
                            session.storeData('userInfo', res.data)
                            that.canRefresh = false
                        } else {
                            prompt.showToast({
                                message: '请登录'
                            })
                            router.replace({
                                uri: "/logIn"
                            })
                        }
                    } else {
                        prompt.showToast({
                            message: '无法连接到服务器，请检查您的网络'
                        })
                    }
                    that.canRefresh = false
                },
                fail: function (data, code) {
                    prompt.showToast({
                        message: '无法连接到服务器，请检查您的网络'
                    })
                }
            })
        }
    })
}
/**
 * function create order id
 */
function getOrderId() {
    var order_id = "";
    for (var i = 0; i < 20; i++)
        order_id += Math.floor(Math.random() * 10);
    return order_id;
}
/**
funciton:get the voice's words
 */
function getVoiceWords(that) {
    record.start({
        duration: 5000,
        sampleRate: 8000,
        numberOfChannels: 1,
        encodeBitRate: 16000,
        format: 'aac',
        success: function (data) {
            request.upload({
                url: that.hostUrl + 'user/book/voice',
                method: 'POST',
                files: [
                    {
                        uri: data.uri,
                        name: 'voice',
                        filename: 'voice.aac'
                    }
                ],
                data: [],
                success: function (res) {
                    prompt.showToast({
                        message: res.data
                    })
                    if (res.data != 'error') {
                        var history = that.history
                        history.push(res.data)
                        history = removeDuplicatedItem(history)
                        session.storeData('searchHistory', history)
                        router.push({
                            uri: '/bookList',
                            params: { key: res.data }
                        })
                    } else {
                        prompt.showToast({
                            message: '识别失败'
                        })
                    }
                },
                fail: function (data, code) {
                    prompt.showToast({
                        message: '上传录音失败' + code + data
                    })
                }
            })
        },
        fail: function (data, code) {
            prompt.showToast({
                message: '授权失败'
            })
        }
    })
}
function removeDuplicatedItem(arr) {
    for (var i = 0; i < arr.length - 1; i++) {
        for (var j = i + 1; j < arr.length; j++) {
            if (arr[i] == arr[j]) {
                arr.splice(j, 1);
                j--;
            }
        }
    }
    return arr;
}
export default {
    scan, copyText, saveImg, getDate, getTime,
    getUnivercitys, getEmailCode, checkEmail, getOrderId,
    checkName, checkTel, checkPasswd, checkEmail,
    checkQQ, getUsernfo, getVoiceWords, removeDuplicatedItem
}
