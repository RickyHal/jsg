import prompt from '@system.prompt'
import storage from '@system.storage'
import fetch from '@system.fetch'
import router from '@system.router'
import request from '@system.request'
import publicFunc from '../public/public.js'
/**
 * filename:book_share.js
 * author:Ricky
 * date:2018/10/27
 * marks:
 * 
 */

/**
 * function:choose the book that you want and purchase it
 * parameter:
 *  1.that
 * return:
 **/
function buy(that) {
    if (that.buyTabbar == false) {
        if (that.stock.length == 0) {
            prompt.showToast({
                message: '请稍后，获取库存信息中。。。'
            })
        } else {
            that.buyTabbar = true
        }
    } else {
        if (that.shoppingCar.total_num == 0) {
            prompt.showToast({
                message: '请先选择教材'
            })
        } else {
            var order = {}
            order.total_num = that.shoppingCar.total_num
            order.total_price = that.shoppingCar.total_price
            order.orderId = publicFunc.getOrderId()
            order.orderTime = publicFunc.getDate() + ' ' + publicFunc.getTime()
            order.sendTime= publicFunc.getDate() + ' ' + publicFunc.getTime()
            var books = []
            for (var i = 0; i < that.shoppingCar.orderInfo.length; i++) {
                if (that.shoppingCar.orderInfo[i].num != 0) {
                    var book = {}
                    book.new = that.shoppingCar.orderInfo[i].newLevel
                    book.num = that.shoppingCar.orderInfo[i].num
                    book.price = that.stock[i].new_price * that.shoppingCar.orderInfo[i].num
                    book.book_name = that.bookInfo_detail.book_name
                    book.sail_id = that.sail_id
                    books.push(book)
                }
            }
            order.books = books
            router.push({
                uri: '/pay',
                params: { order: order }
            })
        }
    }
}

/**
 * function:choose the book that you want and add it to the shoppingcar
 * parameter:
 *  1.that
 * return:
 **/
function addToshoppingCar(that) {
    if (that.buyTabbar == false) {
        if (that.stock.length == 0) {
            prompt.showToast({
                message: '请稍后，获取库存信息中。。。'
            })
        } else {
            that.buyTabbar = true
        }
    } else {
        if (that.shoppingCar.total_num == 0) {
            prompt.showToast({
                message: '请先选择教材'
            })
        } else {
            that.buyTabbar ==false
            that.shoppingCar={
                total_num: 0,
                total_price: 0,
                orderInfo: [{}]
            },
            prompt.showToast({
                message: '加入购物车成功'
            })
            that.stock=[]
            getStock(that)
        }
    }
}

/**
 * function:increase or decrease the number of book in your shoppingcar
 * parameter:
 *  1.that
 *  2.type
 *  3.newLevel
 * return:
 **/
function modifyNum(that, type, index) {
    if (type == '1') {
        if (that.stock[index].new_stock == 0) {
            prompt.showToast({
                message: '您最多只能选择' + that.stock[index].new_stock + '本' + that.stock[index].newLevel + '成新的教材哦'
            })
        } else {
            that.shoppingCar.orderInfo[index].num = parseInt(that.shoppingCar.orderInfo[index].num) + 1
            that.stock[index].new_stock--
            that.shoppingCar.total_num++
            that.shoppingCar.total_price = parseFloat(that.shoppingCar.total_price) + parseFloat(that.stock[index].new_price)
            that.shoppingCar.total_price = Math.round(that.shoppingCar.total_price * 100) / 100
        }
    } else {
        if (that.shoppingCar.orderInfo[index].num > 0) {
            that.shoppingCar.orderInfo[index].num = parseInt(that.shoppingCar.orderInfo[index].num) - 1
            that.shoppingCar.total_num--
            that.stock[index].new_stock++
            that.shoppingCar.total_price = parseFloat(that.shoppingCar.total_price) - parseFloat(that.stock[index].new_price)
            that.shoppingCar.total_price = Math.round(that.shoppingCar.total_price * 100) / 100
        }
    }
}


/**
 * function:choose the book and get information of the book that you choose
 * parameter:
 *  1.that
 * return:
 **/
function getBookInfo(that) {
    storage.get({
        key: 'univercity_id',   //get the session key of user log in flag
        success: function (univercity_id) {
            fetch.fetch({
                data: {
                    'book_isbn': that.book_isbn,
                    'sail_id': that.sail_id,
                    'univercity_id': univercity_id,
                },
                method: 'POST',
                url: that.hostUrl + 'user/book/getBooksInfo_Detail',
                success: function (res) {
                    if (res.code == 200) {
                        res = JSON.parse(res.data)
                        if (res.status == 0) {
                            if (res.data == '') {
                                prompt.showToast({
                                    message: '喔哦，没有这本书哦。。。'
                                })
                                setTimeout(() => {
                                    router.back()
                                }, 1000);
                            } else {
                                that.bookInfo_detail = res.data
                                that.progressShow = false
                                getStock(that)
                            }
                        } else {
                            prompt.showToast({
                                message: '无法连接到服务器，请检查您的网络'
                            })
                        }
                    } else {
                        prompt.showToast({
                            message: '无法连接到服务器，请检查您的网络'
                        })
                    }
                },
                fail: function (data, code) {
                    prompt.showToast({
                        message: '无法连接到服务器，请检查您的网络'
                    })
                }
            })
        }
    })
}


/**
 * function:check the number of book that you want
 * parameter:
 *  1.that
 * return:
 **/
function getStock(that) {
    fetch.fetch({
        data: {
            'sail_id': that.sail_id,
        },
        method: 'POST',
        url: that.hostUrl + 'user/book/getBooksInfo_Stock',
        success: function (res) {
            if (res.code == 200) {
                res = JSON.parse(res.data)
                if (res.status == 0) {
                    if (res.data == '') {
                        prompt.showToast({
                            message: '获取库存信息失败'
                        })
                        that.buyTabbar = false
                    } else {
                        that.stock = res.data
                        //init the shopping car
                        that.shoppingCar.orderInfo = that.stock
                        that.shoppingCar.total_num = 0
                        that.shoppingCar.total_price = 0
                        for (var i = 0; i < that.stock.length; i++) {
                            that.shoppingCar.orderInfo[i].num = 0
                        }
                    }
                } else {
                    prompt.showToast({
                        message: '无法连接到服务器，请检查您的网络'
                    })
                }
            } else {
                prompt.showToast({
                    message: '无法连接到服务器，请检查您的网络'
                })
            }
        },
        fail: function (data, code) {
            prompt.showToast({
                message: '无法连接到服务器，请检查您的网络'
            })
        }
    })
}
/**
 * function:set the nput value to the sign info in data
 * parameter:
 *   1.type:the input info's number
 *   2.e:include the input info
 *   3.that
 * return:
 */
function setValue(index, e, that) {

    //if the input number >stock num
    if (e.target.attr.value > that.stock[index].new_stock) {
        that.shoppingCar.total_num = parseInt(that.shoppingCar.total_num) - parseInt(that.shoppingCar.orderInfo[index].num)
        that.shoppingCar.total_price = parseFloat(that.shoppingCar.total_price) - parseFloat(that.stock[index].new_price) * parseInt(that.shoppingCar.orderInfo[index].num)
        that.stock[index].new_stock = parseInt(that.stock[index].new_stock) + parseInt(that.shoppingCar.orderInfo[index].num)
        that.shoppingCar.orderInfo[index].num = 0
        that.shoppingCar.total_price = Math.round(that.shoppingCar.total_price * 100) / 100
        prompt.showToast({
            message: '您最多只能选择' + that.stock[index].new_stock + '本' + that.stock[index].newLevel + '成新的教材哦'
        })
    } else {
        //if doesn't  input the null value
        if (e.target.attr.value != '' && e.target.attr.value != null) {
            //if the input number >order infomation's number
            if (parseInt(e.target.attr.value.replace(/\s+/g, "")) >= parseInt(that.shoppingCar.orderInfo[index].num)) {
                //set the total number
                that.shoppingCar.total_num = parseInt(that.shoppingCar.total_num) + parseInt(e.target.attr.value) - parseInt(that.shoppingCar.orderInfo[index].num)
                //set the total price
                that.shoppingCar.total_price = parseFloat(that.shoppingCar.total_price) + parseFloat(that.stock[index].new_price) * (parseInt(e.target.attr.value) - parseInt(that.shoppingCar.orderInfo[index].num))
                that.shoppingCar.total_price = Math.round(that.shoppingCar.total_price * 100) / 100
                //set the stock number
                that.stock[index].new_stock = parseInt(that.stock[index].new_stock) + parseInt(that.shoppingCar.orderInfo[index].num) - parseInt(e.target.attr.value)
            } else {
                //if the input number < order infomation's number
                //rollback the total price and total number and stock
                that.shoppingCar.total_num = parseInt(that.shoppingCar.total_num) + parseInt(e.target.attr.value) - parseInt(that.shoppingCar.orderInfo[index].num)
                that.shoppingCar.total_price = parseFloat(that.shoppingCar.total_price) - parseFloat(that.stock[index].new_price) * (parseInt(that.shoppingCar.orderInfo[index].num) - parseInt(e.target.attr.value))
                that.shoppingCar.total_price = Math.round(that.shoppingCar.total_price * 100) / 100
                that.stock[index].new_stock = parseInt(that.stock[index].new_stock) + parseInt(that.shoppingCar.orderInfo[index].num) - parseInt(e.target.attr.value)
            }
            //set the order number
            that.shoppingCar.orderInfo[index].num = e.target.attr.value

        } else {
            //if input the null value
            that.shoppingCar.total_num = parseInt(that.shoppingCar.total_num) - parseInt(that.shoppingCar.orderInfo[index].num)
            if (that.shoppingCar.orderInfo[index].num != 0) {
                that.stock[index].new_stock = parseInt(that.stock[index].new_stock) + parseInt(that.shoppingCar.orderInfo[index].num)
            }
            that.shoppingCar.total_price = parseFloat(that.shoppingCar.total_price) - parseFloat(that.stock[index].new_price) * parseInt(that.shoppingCar.orderInfo[index].num)
            that.shoppingCar.orderInfo[index].num = 0
            that.shoppingCar.total_price = Math.round(that.shoppingCar.total_price * 100) / 100
        }
    }
}
module.exports = {
    buy, addToshoppingCar, modifyNum, getBookInfo, getStock, setValue
}