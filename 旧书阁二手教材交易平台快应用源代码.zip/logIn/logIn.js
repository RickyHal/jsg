/**
 * filename:logIn.js
 * function:
 *  1.setValue: set the user input infomation 
 *  2.logIn:login
 * author:Ricky
 * date:2018/10/30
 * marks:
 * 
 */
import router from '@system.router'
import prompt from '@system.prompt'
import fetch from '@system.fetch'
import session from '../public/sessionData.js'
const user_id = ''
/**
 * function:set the nput value to the sign info in data
 * parameter:
 *   1.type:the input info's number
 *   2.e:include the input info
 *   3.that
 * return:
 */
function setValue(type, e, that) {
    switch (type) {
        case 0:     //input the username
            that.username = e.target.attr.value
            break;
        case 1:     //input the password
            that.passwd = e.target.attr.value
            break;
        default:
    }
}
/**
 * function:login
 * parameter:
 *   1.that
 * return:
 */
function logIn(that) {
    if (that.username == '' || that.passwd == '') {     //if the username or password is null
        prompt.showToast({
            message: '请输入用户名或密码'
        })
    } else {
        fetch.fetch({
            url: that.hostUrl + "user/logIn",
            method: 'POST',
            data: {
                username: that.username,               //user's username
                passwd: that.passwd                     //user's password
            },
            success: function (res) {
                if (res.code == 200) {
                    res = JSON.parse(res.data)
                    if (res.status == 0) {
                        if (res.data.result == 0) {     //login success
                            prompt.showToast({
                                message: '登录成功'
                            })
                            session.storeData('user_id', res.data.session_key)
                            router.replace({
                                uri: '/public'
                            })
                        } else {                  //login failed
                            prompt.showToast({
                                message: '用户名或密码错误'
                            })
                        }
                    } else {                  //use get method
                        prompt.showToast({
                            message: '用户不存在'
                        })
                    }
                } else {
                    prompt.showToast({
                        message: '无法连接到服务器，请检查您的网络'
                    })
                }
            },
            fail: function (data, code) {       //internet error
                prompt.showToast({
                    message: '无法连接到服务器，请检查您的网络'
                })
            }
        })
    }
}
module.exports = {
    setValue, logIn
}